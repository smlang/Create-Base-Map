﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;

namespace Ocad.IO.Ocad9
{
    public class Writer : BinaryWriter
    {
        private const Int32 FILE_RECORD_SIZE = 48;
        private const Int32 SYMBOL_HEADER_SIZE = 4;
        private const Int32 OBJECT_HEADER_SIZE = 40;
        private const Int32 SETTING_HEADER_SIZE = 16;
        private const Int32 SYMBOL_HEADER_BLOCK_SIZE = 4 + (Constant.MAX_HEADERS * SYMBOL_HEADER_SIZE);
        private const Int32 OBJECT_HEADER_BLOCK_SIZE = 4 + (Constant.MAX_HEADERS * OBJECT_HEADER_SIZE);
        private const Int32 SETTING_HEADER_BLOCK_SIZE = 4 + (Constant.MAX_HEADERS * SETTING_HEADER_SIZE);
        internal const Double DOUBLE_BLANK = 0;
        internal const Int32 INT32_BLANK = 0;
        internal const Int16 INT16_BLANK = 0;
        internal const Byte BYTE_BLANK = 0;

        internal Model.Map Map { get; set; }

        public Writer(Stream stream)
            : base(stream, Encoding.Unicode)
        {
        }

        #region Write Methods
        public void Write(Model.Map value)
        {
            Map = value;

            BaseStream.Seek(0, SeekOrigin.Begin);

            #region Determine Size and Position of all records
            Int32 nextOffset = SizeAsciiString(value.FileName.Value) + FILE_RECORD_SIZE;

            Int32 objectHeaderBlockPointer = 0;
            List<Block<Record.Object>> objectBlocks;
            if (value.Objects.Count == 0)
            {
                objectHeaderBlockPointer = 0;
                objectBlocks = new List<Block<Record.Object>>();
            }
            else
            {
                objectHeaderBlockPointer = nextOffset;
                objectBlocks = SizeBlocks<Record.Object>(objectHeaderBlockPointer, ToList<Model.AbstractObject>(value.Objects), OBJECT_HEADER_BLOCK_SIZE, out nextOffset);
            }

            Int32 symbolHeaderBlockPointer;
            List<Block<Record.Symbol>> symbolBlocks;
            if (value.Symbols.Count == 0)
            {
                symbolHeaderBlockPointer = 0;
                symbolBlocks = new List<Block<Record.Symbol>>();
            }
            else
            {
                symbolHeaderBlockPointer = nextOffset;
                symbolBlocks = SizeBlocks<Record.Symbol>(symbolHeaderBlockPointer, ToList<Model.AbstractSymbol>(value.Symbols), SYMBOL_HEADER_BLOCK_SIZE, out nextOffset);
            }

            Int32 settingHeaderBlockPointer;
            List<Block<Record.Setting>> settingBlocks;
            List<Record.Helper.Setting> settings = Record.Helper.Setting.CopyFromModel(Map);
            if (settings.Count == 0)
            {
                settingHeaderBlockPointer = 0;
                settingBlocks = new List<Block<Record.Setting>>();
            }
            else
            {
                settingHeaderBlockPointer = nextOffset;
                settingBlocks = SizeBlocks<Record.Setting>(settingHeaderBlockPointer, ToList<Record.Helper.Setting>(settings), SETTING_HEADER_BLOCK_SIZE, out nextOffset);
            }
            #endregion

            Write(Constant.OCAD_MARK);
            Write((Byte)value.FileType.Value);
            Write(BYTE_BLANK); // fileStatus
            Write(value.FileVersion.Version);
            Write(value.FileVersion.Subversion);
            Write(symbolHeaderBlockPointer); // Int32 symbolHeaderBlockPointer = WriteInt();
            Write(objectHeaderBlockPointer); // Int32 objectHeaderBlockPointer = WriteInt();
            Write(INT32_BLANK); // reserved0
            Write(INT32_BLANK); // reserved1
            Write(INT32_BLANK); // reserved2
            Write(INT32_BLANK); // infoSize
            Write(settingHeaderBlockPointer); // Int32 settingHeaderBlockPointer = WriteInt();
            Write(FILE_RECORD_SIZE); // Int32 fileNamePointer = WriteInt();
            Write(INT32_BLANK);  // Int32 fileNameSize = WriteInt();
            Write(INT32_BLANK); // reserved4

            #region Write Records
            WriteAsciiString(value.FileName.Value);
            Write<Record.Object>(objectBlocks, OBJECT_HEADER_SIZE);
            Write<Record.Symbol>(symbolBlocks, SYMBOL_HEADER_SIZE);
            Write<Record.Setting>(settingBlocks, SETTING_HEADER_SIZE);
            #endregion
        }

        private static List<object> ToList<T>(List<T> value)
        {
            List<object> output = new List<object>();
            foreach (object o in value)
            {
                output.Add(o);
            }
            return output;
        }

        internal void WriteWordBoolean(Boolean value)
        {
            Write(BYTE_BLANK);
            Write(value);
        }

        internal void WriteEncodedString(String value)
        {
            Write(value.ToCharArray());

            Int32 padding = SizeEncodedString(value);
            padding -= (value.Length * 2);
            Write(new byte[padding]);
        }

        internal void WriteAsciiString(String value)
        {
            Write(Encoding.ASCII.GetBytes(value));

            Int32 padding = SizeAsciiString(value);
            padding -= value.Length;
            Write(new byte[padding]);
        }

        internal void WritePascalString(String value, Int32 maxSize)
        {
            if (value.Length > maxSize)
            {
                value = value.Substring(0, maxSize);
            }

            Write((byte)value.Length);
            Write(Encoding.ASCII.GetBytes(value));
            Int32 padding = maxSize - value.Length;
            Write(new byte[padding]);
        }

        internal void Write(Model.Point value)
        {
            Int32 x, y;
            if (value.SecondBezierUse)
            {
                x = ((int)(value.SecondBezierXMm * 100) << 8) + (((int)Type.PointFlag.SecondBezierPoint) & 255);
                Write(x);
                y = ((int)(value.SecondBezierYMm * 100) << 8) + ((((int)Type.PointFlag.SecondBezierPoint) >> 8) & 255);
                Write(y);
            }

            x = ((int)(value.MainXMm * 100) << 8) + (((int)value.MainPointFlag) & 255);
            Write(x);
            y = ((int)(value.MainYMm * 100) << 8) + ((((int)value.MainPointFlag) >> 8) & 255);
            Write(y);

            if (value.FirstBezierUse)
            {
                x = ((int)(value.FirstBezierXMm * 100) << 8) + (((int)Type.PointFlag.FirstBezierPoint) & 255);
                Write(x);
                y = ((int)(value.FirstBezierYMm * 100) << 8) + ((((int)Type.PointFlag.FirstBezierPoint) >> 8) & 255);
                Write(y);
            }
        }

        internal void Write(List<Model.Point> value)
        {
            foreach (Model.Point p in value)
            {
                Write(p);
            }
        }

        internal void Write(Model.Shape value)
        {
            Write((Int16)value.Type);
            Write((UInt16)value.Style);
            Write(value.Colour);
            Write((Int16)(value.LineWidthMm * 100));
            Write((Int16)(value.DiameterMm * 100));
            Write((Int16)(Size(value.Points) / 8));
            Write(INT16_BLANK);  // reserved0
            Write(INT16_BLANK);  // reserved1
            Write(value.Points);
        }

        internal void Write(List<Model.Shape> value)
        {
            foreach (Model.Shape s in value)
            {
                Write(s);
            }
        }

        internal void Write(Model.Colour value)
        {
            if (value != null)
            {
                Write(value.Number);
            }
            else
            {
                Write(INT16_BLANK);
            }
        }

        internal void Write(Model.SymbolTree value)
        {
            if (value != null)
            {
                Write((Byte)value.GroupId);
            }
            else
            {
                Write(BYTE_BLANK);
            }
        }

        internal void Write(Model.ImportLayer value)
        {
            if (value != null)
            {
                Write((Int16)value.LayerNumber);
            }
            else
            {
                Write(INT16_BLANK);
            }
        }

        internal void Write<R>(List<Block<R>> blocks, Int32 recordHeaderSize) where R : Record.AbstractRecord, new()
        {
            R blankRecord = new R();
            for (int i = 0; i < blocks.Count; i++)
            {
                Int32 nextBlockPoint = (i == blocks.Count-1) ? 0 : blocks[i + 1].BlockPointer;
                Write(nextBlockPoint);
                for (int j = 0; j < blocks[i].Records.Count; j++)
                {
                    R record = blocks[i].Records[j];
                    record.WriteHeader(this);
                }
                Int32 blankRecordHeaders = Constant.MAX_HEADERS - blocks[i].Records.Count;
                Write(new byte[blankRecordHeaders * recordHeaderSize]);

                for (int j = 0; j < blocks[i].Records.Count; j++)
                {
                    R record = blocks[i].Records[j];
                    record.WriteBody(this);
                }
            }
        }

        internal protected static Int32 ConvertFromSymbolNumber(String symbolNumber)
        {
            String[] parts = symbolNumber.Split('.');
            Int32 symbolNumberInteger = Int32.Parse(parts[0]) * 1000;
            if (parts.Length > 1)
            {
                symbolNumberInteger += Int32.Parse(parts[1]);
            }
            return symbolNumberInteger;
        }

        #region Size Methods
        internal Int32 SizeEncodedString(String value)
        {
            return 64 * (((value.Length * 2) + 64) / 64);
        }

        internal Int32 SizeAsciiString(String value)
        {
            return 64 * ((value.Length + 64) / 64);
        }

        internal Int32 Size(List<Model.Point> value)
        {
            Int32 size = 0;
            foreach (Model.Point p in value)
            {
                size += 8;
                if (p.SecondBezierUse)
                {
                    size += 8;
                }
                if (p.FirstBezierUse)
                {
                    size += 8;
                }
            }
            return size;
        }

        internal Int32 Size(List<Model.Shape> value)
        {
            Int32 size = 0;
            foreach (Model.Shape s in value)
            {
                size += 16;
                size += Size(s.Points);
            }
            return size;
        }

        private List<Block<R>> SizeBlocks<R>(Int32 offset, List<object> items, Int32 blockSize, out Int32 newOffset) where R : Record.AbstractRecord, new()
        {
            List<Block<R>> blocks = new List<Block<R>>();
            Block<R> block = new Block<R>();
            newOffset = offset;
            int i = 0;
            foreach (object item in items)
            {
                if (i == Constant.MAX_HEADERS)
                {
                    i = 0;
                }
                if (i == 0)
                {
                    block = new Block<R>();
                    block.BlockPointer = newOffset;
                    block.Records = new List<R>();
                    blocks.Add(block);

                    newOffset += blockSize;
                }

                R record = new R();
                newOffset = record.SizeBody(this, newOffset, item);
                block.Records.Add(record);

                i++;
            }
            return blocks;
        }
        #endregion

        internal struct Block<R>
        {
            internal Int32 BlockPointer;
            internal List<R> Records;
        }
        #endregion
    }
}
