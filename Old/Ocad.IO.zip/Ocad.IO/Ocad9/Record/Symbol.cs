﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace Ocad.IO.Ocad9.Record
{
    internal class Symbol : AbstractRecord
    {
        private const Int32 AREA_BASIC_BODY_SIZE = 604;
        private const Int32 BLOCK_TEXT_BASIC_BODY_SIZE = 812;
        private const Int32 LINE_BASIC_BODY_SIZE = 648;
        private const Int32 LINE_TEXT_BASIC_BODY_SIZE = 664;
        private const Int32 POINT_BASIC_BODY_SIZE = 576;
        private const Int32 RECTANGLE_BASIC_BODY_SIZE = 640;
        private const Int32 ICON_SIZE = 484;
        
        private const Int32 MAX_COLOURS = 14;
        private const Int32 MAX_TABS = 32;

        private const Int32 MAX_DESCRIPTION_SIZE = 31;
        private const Int32 MAX_FONT_NAME_SIZE = 31;
        private const Int32 MAX_LINE_RESERVED_SIZE = 31;
        private const Int32 MAX_BLOCK_TEXT_RESERVED_SIZE = 23;
        private const Int32 MAX_UNNUMBERED_CELLS_SIZE = 3;
        private const Int32 MAX_RECTANGLE_RESERVED_SIZE = 31;        

        private Model.AbstractSymbol symbol;
        private Int32 dataByteSize = 0;

        internal override void ReadHeader(Reader reader)
        {
            BodyPointer = reader.ReadInt32();
        }

        internal override void ReadBody(Reader reader)
        {
            reader.BaseStream.Seek(BodyPointer, SeekOrigin.Begin);

            BodyByteSize = reader.ReadInt32(); // Record Size
            String symbolNumber = Reader.ConvertToSymbolNumber(reader.ReadInt32()); // Symbol Number
            Model.Type.SymbolType symbolType = (Model.Type.SymbolType)reader.ReadByte();

            Model.AbstractSymbol symbol = MapExtension.GetOrCreateSymbol(reader.Map, symbolNumber, symbolType, true);

            switch (symbolType)
            {
                case Model.Type.SymbolType.Area:
                    ReadArea(reader, (Model.AreaSymbol)symbol);
                    break;
                case Model.Type.SymbolType.BlockText:
                    ReadBlockText(reader, (Model.BlockTextSymbol)symbol);
                    break;
                case Model.Type.SymbolType.Line:
                    ReadLine(reader, (Model.LineSymbol)symbol);
                    break;
                case Model.Type.SymbolType.LineText:
                    ReadLineText(reader, (Model.LineTextSymbol)symbol);
                    break;
                case Model.Type.SymbolType.Point:
                    ReadPoint(reader, (Model.PointSymbol)symbol);
                    break;
                case Model.Type.SymbolType.Rectangle:
                    ReadRectangle(reader, (Model.RectangleSymbol)symbol);
                    break;
                default:
                    symbol = null; // todo throw null
                    break;
            }           
        }

        #region Read Body Methods
        private void ReadAbstractSymbol(Reader reader, Model.AbstractSymbol symbol)
        {
            symbol.Flag = (Model.Type.SymbolFlag)reader.ReadByte();
            symbol.Selected = reader.ReadBoolean();
            symbol.Status = (Model.Type.SymbolStatus)reader.ReadByte();
            symbol.DefaultDrawingMode = (Model.Type.DefaultDrawingMode)reader.ReadByte();
            symbol.EventMode = (Model.Type.EventMode)reader.ReadByte();
            symbol.CourseObjectType = (Model.Type.ControlObjectType)reader.ReadByte();
            symbol.CourseDescriptionFlag = (Model.Type.CourseDescriptionFlag)reader.ReadByte();
            symbol.ExtentMm = reader.ReadInt32() / 100.0;
            reader.ReadInt32(); // filePosition
            symbol.SymbolTree1 = MapExtension.GetOrCreateSymbolTree(reader.Map, reader.ReadByte());
            symbol.SymbolTree2 = MapExtension.GetOrCreateSymbolTree(reader.Map, reader.ReadByte());
            reader.ReadInt16(); // Int16 nColours
            for (int i = 0; i < MAX_COLOURS; i++)
            {
                reader.ReadInt16(); // In16 Colours[i] -- colours are described in other properties
            }

            symbol.Description = reader.ReadPascalString(MAX_DESCRIPTION_SIZE);
            symbol.IconBits = reader.ReadBytes(ICON_SIZE);
        }

        private void ReadArea(Reader reader, Model.AreaSymbol symbol)
        {
            ReadAbstractSymbol(reader, symbol);
            Int32 borderSymbolInteger = reader.ReadInt32();
            Int16 fillColourNumber = reader.ReadInt16();
            symbol.HatchMode = (Model.Type.HatchMode)reader.ReadInt16();
            Int16 hatchColourNumber = reader.ReadInt16();
            if (symbol.HatchMode != Model.Type.HatchMode.Off)
            {
                symbol.HatchColour = MapExtension.GetOrCreateColour(reader.Map, hatchColourNumber);
            }
            symbol.HatchLineWidthMm = reader.ReadInt16() / 100.0;
            symbol.HatchDistanceMm = reader.ReadInt16() / 100.0;
            symbol.HatchAngle1Degree = reader.ReadInt16() / 10.0;
            symbol.HatchAngle2Degree = reader.ReadInt16() / 10.0;
            symbol.FillOn = reader.ReadBoolean();
            if (symbol.FillOn)
            {
                symbol.FillColour = MapExtension.GetOrCreateColour(reader.Map, fillColourNumber);
            }
            symbol.BorderOn = reader.ReadBoolean();
            if (symbol.BorderOn)
            {
                String borderSymbolNumber = Reader.ConvertToSymbolNumber(borderSymbolInteger); // Symbol Number
                symbol.BorderSymbol = (Model.LineSymbol)MapExtension.GetOrCreateSymbol(reader.Map, borderSymbolNumber, Model.Type.FeatureType.Line);
            }
            symbol.StuctureMode = (Model.Type.StructureMode)reader.ReadInt16();
            symbol.StuctureWidthMm = reader.ReadInt16() / 100.0;
            symbol.StuctureHeightMm = reader.ReadInt16() / 100.0;
            symbol.StuctureAngleDegree = reader.ReadInt16() / 10.0;
            reader.ReadInt16(); // reserved0
            UInt16 dataSize = reader.ReadUInt16();
            symbol.Shapes = reader.ReadShapes(dataSize);
        }

        private void ReadLine(Reader reader, Model.LineSymbol symbol)
        {
            ReadAbstractSymbol(reader, symbol);

            symbol.LineColour = MapExtension.GetOrCreateColour(reader.Map, reader.ReadInt16());
            symbol.LineWidthMm = reader.ReadInt16() / 100.0;
            symbol.LineStyle = (Model.Type.LineStyle)reader.ReadInt16();

            symbol.DistanceFromStartMm = reader.ReadInt16() / 100.0;
            symbol.DistanceFromEndMm = reader.ReadInt16() / 100.0;
            symbol.MainLengthAMm = reader.ReadInt16() / 100.0;
            symbol.EndLengthBMm = reader.ReadInt16() / 100.0;
            symbol.MainGapCMm = reader.ReadInt16() / 100.0;
            symbol.MinorGapDMm = reader.ReadInt16() / 100.0;
            symbol.EndGapEMm = reader.ReadInt16() / 100.0;
            symbol.MinimumNumberOfGaps = reader.ReadInt16();
            symbol.MinimumNumberOfGaps++;

            symbol.NMainSymbolA = reader.ReadInt16();
            symbol.MainSymbolDistanceMm = reader.ReadInt16() / 100.0;

            symbol.DoubleMode = (Model.Type.DoubleLineMode)reader.ReadUInt16();
            symbol.DoubleFlag = (Model.Type.DoubleLineFlag)reader.ReadUInt16();
            Int16 doubleFillColourNumber = reader.ReadInt16();
            Int16 doubleLeftColourNumber = reader.ReadInt16();
            Int16 doubleRightColourNumber = reader.ReadInt16();
            if (symbol.DoubleMode != Model.Type.DoubleLineMode.Off)
            {
                if (symbol.DoubleFlag != Model.Type.DoubleLineFlag.None)
                {
                    symbol.DoubleFillColour = MapExtension.GetOrCreateColour(reader.Map, doubleFillColourNumber);
                }
                symbol.DoubleLeftColour = MapExtension.GetOrCreateColour(reader.Map, doubleLeftColourNumber);
                symbol.DoubleRightColour = MapExtension.GetOrCreateColour(reader.Map, doubleRightColourNumber);
            }

            symbol.DoubleWidthMm = reader.ReadInt16() / 100.0;
            symbol.DoubleLeftWidthMm = reader.ReadInt16() / 100.0;
            symbol.DoubleRightWidthMm = reader.ReadInt16() / 100.0;
            symbol.DoubleDashedLengthMm = reader.ReadInt16() / 100.0;
            symbol.DoubleDashedGapMm = reader.ReadInt16() / 100.0;

            reader.ReadInt16(); // reserved0
            reader.ReadInt16(); // reserved1[0]
            reader.ReadInt16(); // reserved1[1]

            symbol.DecreaseMode = (Model.Type.DecreaseMode)reader.ReadUInt16();
            symbol.DecreaseLastSymbolPercentageOfNormalSize = reader.ReadInt16();

            reader.ReadInt16(); // reserved2
            symbol.FramingColour = MapExtension.GetOrCreateColour(reader.Map, reader.ReadInt16());
            symbol.FramingWidthMm = reader.ReadInt16() / 100.0;
            symbol.FramingStyle = (Model.Type.FramingStyle)reader.ReadInt16();

            UInt16 mainSymbolADataSize = reader.ReadUInt16();
            UInt16 secondarySymbolBDataSize = reader.ReadUInt16();
            UInt16 cornerSymbolDataSize = reader.ReadUInt16();
            UInt16 startSymbolCDataSize = reader.ReadUInt16();
            UInt16 endSymbolDDataSize = reader.ReadUInt16();
            reader.ReadInt16(); // reserved3

            symbol.MainSymbolAShapes = reader.ReadShapes(mainSymbolADataSize);
            symbol.SecondarySymbolBShapes = reader.ReadShapes(secondarySymbolBDataSize);
            symbol.CornerSymbolShapes = reader.ReadShapes(cornerSymbolDataSize);
            symbol.StartSymbolCShapes = reader.ReadShapes(startSymbolCDataSize);
            symbol.EndSymbolDShapes = reader.ReadShapes(endSymbolDDataSize);
        }

        private void ReadPoint(Reader reader, Model.PointSymbol symbol)
        {
            ReadAbstractSymbol(reader, symbol);

            UInt16 dataSize = reader.ReadUInt16();
            reader.ReadInt16(); //reserved
            symbol.Shapes = reader.ReadShapes(dataSize);
        }

        private void ReadAbstractText(Reader reader, Model.AbstractTextSymbol symbol)
        {
            ReadAbstractSymbol(reader, symbol);

            symbol.FontName = reader.ReadPascalString(MAX_FONT_NAME_SIZE);
            symbol.FontColour = MapExtension.GetOrCreateColour(reader.Map, reader.ReadInt16());
            symbol.FontSize = reader.ReadInt16() / 10.0;
            symbol.FontWeight = (Model.Type.FontWeight)reader.ReadInt16();
            symbol.FontItalic = reader.ReadBoolean();
            reader.ReadByte(); // reserved0
            symbol.CharacterSpacingPercentageOfSpace = reader.ReadInt16();
            symbol.WordSpacingPercentageOfSpace = reader.ReadInt16();
            symbol.TextAlignment = (Model.Type.TextAlignment)reader.ReadInt16();
        }

        private void ReadLineText(Reader reader, Model.LineTextSymbol symbol)
        {
            ReadAbstractText(reader, symbol);

            symbol.FramingMode = (Model.Type.FramingMode)reader.ReadByte();
            reader.ReadByte(); // reserved1
            reader.ReadPascalString(MAX_LINE_RESERVED_SIZE); // reserved2
            Int16 framingColourNumber = reader.ReadInt16();
            if (symbol.FramingMode != Model.Type.FramingMode.Off)
            {
                symbol.FramingColour = MapExtension.GetOrCreateColour(reader.Map, framingColourNumber);
            }
            symbol.FramingWidthMm = reader.ReadInt16() / 100.0;
            reader.ReadInt16(); // reserved3
            reader.ReadWordBoolean(); // reserved4
            symbol.FramingShadowXMm = reader.ReadInt16() / 100.0;
            symbol.FramingShadowYMm = reader.ReadInt16() / 100.0;
        }

        private void ReadBlockText(Reader reader, Model.BlockTextSymbol symbol)
        {
            ReadAbstractText(reader, symbol);

            symbol.LineSpacingPercentageOfFontSize = reader.ReadInt16();
            symbol.SpaceAfterParagraphMm = reader.ReadInt16() / 100.0;
            symbol.IdentFirstLineMm = reader.ReadInt16() / 100.0;
            symbol.IdentOtherLinesMm = reader.ReadInt16() / 100.0;
            Int16 nTabs = reader.ReadInt16();
            for (int i = 0; i < MAX_TABS; i++)
            {
                if (i < nTabs)
                {
                    symbol.TabsMm.Add(reader.ReadInt32() / 100.0);
                }
                else
                {
                    reader.ReadInt32();
                }
            }

            symbol.LineBelowOn = reader.ReadWordBoolean();
            Int16 lineBelowColourNumber = reader.ReadInt16();
            if (symbol.LineBelowOn)
            {
                symbol.LineBelowColour = MapExtension.GetOrCreateColour(reader.Map, lineBelowColourNumber);
            }
            symbol.LineBelowWidthMm = reader.ReadInt16() / 100.0;
            symbol.LineBelowDistanceMm = reader.ReadInt16() / 100.0;
            reader.ReadInt16(); // reserved1

            symbol.FramingMode = (Model.Type.FramingMode)reader.ReadByte();
            symbol.FramingLineStyle = (Model.Type.LineStyle)reader.ReadByte();
            reader.ReadPascalString(MAX_BLOCK_TEXT_RESERVED_SIZE); // reserved2
            symbol.FramingLeftMm = reader.ReadInt16() / 100.0;
            symbol.FramingBottomMm = reader.ReadInt16() / 100.0;
            symbol.FramingRightMm = reader.ReadInt16() / 100.0;
            symbol.FramingTopMm = reader.ReadInt16() / 100.0;
            Int16 framingColourNumber = reader.ReadInt16();
            if (symbol.FramingMode != Model.Type.FramingMode.Off)
            {
                symbol.FramingColour = MapExtension.GetOrCreateColour(reader.Map, framingColourNumber);
            }
            symbol.FramingWidthMm = reader.ReadInt16() / 100.0;

            reader.ReadInt16(); // reserved3
            reader.ReadWordBoolean(); // reserved4
            symbol.FramingShadowXMm = reader.ReadInt16() / 100.0;
            symbol.FramingShadowYMm = reader.ReadInt16() / 100.0;
        }

        private void ReadRectangle(Reader reader, Model.RectangleSymbol symbol)
        {
            ReadAbstractSymbol(reader, symbol);

            symbol.LineColour = MapExtension.GetOrCreateColour(reader.Map, reader.ReadInt16());
            symbol.LineWidthMm = reader.ReadInt16() / 100.0;
            symbol.RadiusMm = reader.ReadInt16() / 100.0;
            symbol.GridFlags = (Model.Type.GridFlag)reader.ReadUInt16();
            symbol.CellWidthMm = reader.ReadInt16() / 100.0;
            symbol.CellHeightMm = reader.ReadInt16() / 100.0;
            reader.ReadInt16(); // reserved0
            reader.ReadInt16(); // reserved1
            symbol.UnnumberedCells = reader.ReadInt16();
            symbol.UnnumberedCellsText = reader.ReadPascalString(MAX_UNNUMBERED_CELLS_SIZE);
            reader.ReadInt16(); // reserved2
            reader.ReadPascalString(MAX_RECTANGLE_RESERVED_SIZE); // reserved3
            reader.ReadInt16(); // reserved4
            symbol.FontSize = reader.ReadInt16() / 10.0;
            reader.ReadInt16(); // reserved6
            reader.ReadWordBoolean(); // reserved7
            reader.ReadInt16(); // reserved8
            reader.ReadInt16(); // reserved9
        }
        #endregion

        internal override Int32 SizeBody(Writer writer, Int32 offset, object o)
        {
            symbol = (Model.AbstractSymbol)o;
            BodyPointer = offset;

            switch (symbol.Type)
            {
                case Model.Type.SymbolType.Area:
                    BodyByteSize = AREA_BASIC_BODY_SIZE; // plus shapes
                    Model.AreaSymbol area = (Model.AreaSymbol)symbol;
                    dataByteSize = writer.Size(area.Shapes);
                    BodyByteSize += dataByteSize;
                    break;
                case Model.Type.SymbolType.BlockText:
                    BodyByteSize = BLOCK_TEXT_BASIC_BODY_SIZE;
                    break;
                case Model.Type.SymbolType.Line:
                    BodyByteSize = LINE_BASIC_BODY_SIZE; // plus shapes
                    Model.LineSymbol line = (Model.LineSymbol)symbol;
                    dataByteSize = writer.Size(line.MainSymbolAShapes);
                    dataByteSize += writer.Size(line.SecondarySymbolBShapes);
                    dataByteSize += writer.Size(line.CornerSymbolShapes);
                    dataByteSize += writer.Size(line.StartSymbolCShapes);
                    dataByteSize += writer.Size(line.EndSymbolDShapes);
                    BodyByteSize += dataByteSize;
                    break;
                case Model.Type.SymbolType.LineText:
                    BodyByteSize = LINE_TEXT_BASIC_BODY_SIZE;
                    break;
                case Model.Type.SymbolType.Point:
                    BodyByteSize = POINT_BASIC_BODY_SIZE; // plus shapes
                    Model.PointSymbol point = (Model.PointSymbol)symbol;
                    dataByteSize = writer.Size(point.Shapes);
                    BodyByteSize += dataByteSize;
                    break;
                case Model.Type.SymbolType.Rectangle:
                    BodyByteSize = RECTANGLE_BASIC_BODY_SIZE;
                    break;
            }
            
            return BodyPointer + BodyByteSize;
        }

        internal override void WriteHeader(Writer writer)
        {
            writer.Write(BodyPointer);
        }

        internal override void WriteBody(Writer writer)
        {
            writer.Write(BodyByteSize);
            writer.Write(Writer.ConvertFromSymbolNumber(symbol.Number));
            writer.Write((Byte)symbol.Type);

            switch (symbol.Type)
            {
                case Model.Type.SymbolType.Area:
                    WriteArea(writer, (Model.AreaSymbol)this.symbol);
                    break;
                case Model.Type.SymbolType.BlockText:
                    WriteBlockText(writer, (Model.BlockTextSymbol)this.symbol);
                    break;
                case Model.Type.SymbolType.Line:
                    WriteLine(writer, (Model.LineSymbol)this.symbol);
                    break;
                case Model.Type.SymbolType.LineText:
                    WriteLineText(writer, (Model.LineTextSymbol)this.symbol);
                    break;
                case Model.Type.SymbolType.Point:
                    WritePoint(writer, (Model.PointSymbol)this.symbol);
                    break;
                case Model.Type.SymbolType.Rectangle:
                    WriteRectangle(writer, (Model.RectangleSymbol)this.symbol);
                    break;
            }
        }

        #region Write Body Methods
        private void WriteAbstractSymbol(Writer writer, Model.AbstractSymbol symbol)
        {
            writer.Write((Byte)symbol.Flag);
            writer.Write(symbol.Selected);
            writer.Write((Byte)symbol.Status);
            writer.Write((Byte)symbol.DefaultDrawingMode);
            writer.Write((Byte)symbol.EventMode);
            writer.Write((Byte)symbol.CourseObjectType);
            writer.Write((Byte)symbol.CourseDescriptionFlag);
            writer.Write((Int32)(symbol.ExtentMm * 100));
            writer.Write(Writer.INT32_BLANK); // filePosition
            writer.Write(symbol.SymbolTree1);
            writer.Write(symbol.SymbolTree2);
            List<Model.Colour> colours = symbol.Colours;
            if (colours.Count <= MAX_COLOURS)
            {
                writer.Write((Int16)colours.Count);
            }
            else
            {
                writer.Write((Int16)(-1));
            }

            for (int i = 0; i < MAX_COLOURS; i++)
            {
                if (i < colours.Count)
                {
                    writer.Write(colours[i]);
                }
                else
                {
                    writer.Write(Writer.INT16_BLANK);
                }
            }
            writer.WritePascalString(symbol.Description, MAX_DESCRIPTION_SIZE);
            writer.Write(symbol.IconBits);            
        }

        private void WriteArea(Writer writer, Model.AreaSymbol symbol)
        {
            WriteAbstractSymbol(writer, symbol);

            if (symbol.BorderOn)
            {
                writer.Write(Writer.ConvertFromSymbolNumber(symbol.BorderSymbol.Number));
            }
            else
            {
                writer.Write(Writer.INT32_BLANK);
            }

            writer.Write(symbol.FillColour);
            writer.Write((Int16)symbol.HatchMode);
            writer.Write(symbol.HatchColour);
            writer.Write((Int16)(symbol.HatchLineWidthMm * 100));
            writer.Write((Int16)(symbol.HatchDistanceMm * 100));
            writer.Write((Int16)(symbol.HatchAngle1Degree * 10));
            writer.Write((Int16)(symbol.HatchAngle2Degree * 10));
            writer.Write(symbol.FillOn);
            writer.Write(symbol.BorderOn);
            writer.Write((Int16)symbol.StuctureMode);
            writer.Write((Int16)(symbol.StuctureWidthMm * 100));
            writer.Write((Int16)(symbol.StuctureHeightMm * 100));
            writer.Write((Int16)(symbol.StuctureAngleDegree * 10));
            writer.Write(Writer.INT16_BLANK); // reserved0
            writer.Write((UInt16)(dataByteSize / Constant.DATA_SIZE));
            writer.Write(symbol.Shapes);
        }

        private void WriteLine(Writer writer, Model.LineSymbol symbol)
        {
            WriteAbstractSymbol(writer, symbol);

            writer.Write(symbol.LineColour);
            writer.Write((Int16)(symbol.LineWidthMm * 100));
            writer.Write((Int16)symbol.LineStyle);
            writer.Write((Int16)(symbol.DistanceFromStartMm * 100));
            writer.Write((Int16)(symbol.DistanceFromEndMm * 100));
            writer.Write((Int16)(symbol.MainLengthAMm * 100));
            writer.Write((Int16)(symbol.EndLengthBMm * 100));
            writer.Write((Int16)(symbol.MainGapCMm * 100));
            writer.Write((Int16)(symbol.MinorGapDMm * 100));
            writer.Write((Int16)(symbol.EndGapEMm * 100));
            writer.Write((Int16)(symbol.MinimumNumberOfGaps - 1));
            writer.Write(symbol.NMainSymbolA);
            writer.Write((Int16)(symbol.MainSymbolDistanceMm * 100));

            writer.Write((UInt16)symbol.DoubleMode);
            writer.Write((UInt16)symbol.DoubleFlag);
            writer.Write(symbol.DoubleFillColour);
            writer.Write(symbol.DoubleLeftColour);
            writer.Write(symbol.DoubleRightColour);
            writer.Write((Int16)(symbol.DoubleWidthMm * 100));
            writer.Write((Int16)(symbol.DoubleLeftWidthMm * 100));
            writer.Write((Int16)(symbol.DoubleRightWidthMm * 100));
            writer.Write((Int16)(symbol.DoubleDashedLengthMm * 100));
            writer.Write((Int16)(symbol.DoubleDashedGapMm * 100));
            writer.Write(Writer.INT16_BLANK); // reserved0
            writer.Write(Writer.INT16_BLANK); // reserved1[0]
            writer.Write(Writer.INT16_BLANK); // reserved1[1]
            writer.Write((UInt16)symbol.DecreaseMode);
            writer.Write(symbol.DecreaseLastSymbolPercentageOfNormalSize);
            writer.Write(Writer.INT16_BLANK); // reserved2
            writer.Write(symbol.FramingColour);
            writer.Write((Int16)(symbol.FramingWidthMm * 100));
            writer.Write((Int16)symbol.FramingStyle);

            writer.Write((UInt16)(writer.Size(symbol.MainSymbolAShapes) / Constant.DATA_SIZE));
            writer.Write((UInt16)(writer.Size(symbol.SecondarySymbolBShapes) / Constant.DATA_SIZE));
            writer.Write((UInt16)(writer.Size(symbol.CornerSymbolShapes) / Constant.DATA_SIZE));
            writer.Write((UInt16)(writer.Size(symbol.StartSymbolCShapes) / Constant.DATA_SIZE));
            writer.Write((UInt16)(writer.Size(symbol.EndSymbolDShapes) / Constant.DATA_SIZE));
            writer.Write(Writer.INT16_BLANK); // reserved3
            writer.Write(symbol.MainSymbolAShapes);
            writer.Write(symbol.SecondarySymbolBShapes);
            writer.Write(symbol.CornerSymbolShapes);
            writer.Write(symbol.StartSymbolCShapes);
            writer.Write(symbol.EndSymbolDShapes);
        }

        private void WritePoint(Writer writer, Model.PointSymbol symbol)
        {
            WriteAbstractSymbol(writer, symbol);

            writer.Write((UInt16)(dataByteSize / Constant.DATA_SIZE));
            writer.Write(Writer.INT16_BLANK);
            writer.Write(symbol.Shapes);
        }

        private void WriteAbstractText(Writer writer, Model.AbstractTextSymbol symbol)
        {
            WriteAbstractSymbol(writer, symbol);

            writer.WritePascalString(symbol.FontName, MAX_FONT_NAME_SIZE);
            writer.Write(symbol.FontColour);
            writer.Write((Int16)(symbol.FontSize * 10));
            writer.Write((Int16)symbol.FontWeight);
            writer.Write(symbol.FontItalic);
            writer.Write(Writer.BYTE_BLANK); // reserved0
            writer.Write(symbol.CharacterSpacingPercentageOfSpace);
            writer.Write(symbol.WordSpacingPercentageOfSpace);
            writer.Write((Int16)symbol.TextAlignment);
        }

        private void WriteLineText(Writer writer, Model.LineTextSymbol symbol)
        {
            WriteAbstractText(writer, symbol);

            writer.Write((Byte)symbol.FramingMode);
            writer.Write(Writer.BYTE_BLANK); // reserved1
            writer.WritePascalString(String.Empty, MAX_LINE_RESERVED_SIZE); // reserved2
            writer.Write(symbol.FramingColour);
            writer.Write((Int16)(symbol.FramingWidthMm * 100));
            writer.Write(Writer.INT16_BLANK); // reserved3
            writer.WriteWordBoolean(false); //reserved4
            writer.Write((Int16)(symbol.FramingShadowXMm * 100));
            writer.Write((Int16)(symbol.FramingShadowYMm * 100));
        }

        private void WriteBlockText(Writer writer, Model.BlockTextSymbol symbol)
        {
            WriteAbstractText(writer, symbol);

            writer.Write(symbol.LineSpacingPercentageOfFontSize);
            writer.Write((Int16)(symbol.SpaceAfterParagraphMm * 100));
            writer.Write((Int16)(symbol.IdentFirstLineMm * 100));
            writer.Write((Int16)(symbol.IdentOtherLinesMm * 100));
            Int32 nTabs = symbol.TabsMm.Count;
            if (nTabs > MAX_TABS)
            {
                nTabs = MAX_TABS;
            }
            writer.Write((Int16)nTabs);
            for (int i = 0; i < MAX_TABS; i++)
            {
                if (i < nTabs)
                {
                    writer.Write((Int32)(symbol.TabsMm[i] * 100));
                }
                else
                {
                    writer.Write(Writer.INT32_BLANK);
                }
            }
            writer.WriteWordBoolean(symbol.LineBelowOn);
            writer.Write(symbol.LineBelowColour);
            writer.Write((Int16)(symbol.LineBelowWidthMm * 100));
            writer.Write((Int16)(symbol.LineBelowDistanceMm * 100));
            writer.Write(Writer.INT16_BLANK); // reserved1
            writer.Write((Byte)symbol.FramingMode);
            writer.Write((Byte)symbol.FramingLineStyle);
            writer.WritePascalString(String.Empty, MAX_BLOCK_TEXT_RESERVED_SIZE); // reserved2
            writer.Write((Int16)(symbol.FramingLeftMm * 100));
            writer.Write((Int16)(symbol.FramingBottomMm * 100));
            writer.Write((Int16)(symbol.FramingRightMm * 100));
            writer.Write((Int16)(symbol.FramingTopMm * 100));
            writer.Write(symbol.FramingColour);
            writer.Write((Int16)(symbol.FramingWidthMm * 100));
            writer.Write(Writer.INT16_BLANK); // reserved3
            writer.WriteWordBoolean(false); //reserved4
            writer.Write((Int16)(symbol.FramingShadowXMm * 100));
            writer.Write((Int16)(symbol.FramingShadowYMm * 100));
        }

        private void WriteRectangle(Writer writer, Model.RectangleSymbol symbol)
        {
            WriteAbstractSymbol(writer, symbol);

            writer.Write(symbol.LineColour);
            writer.Write((Int16)(symbol.LineWidthMm * 100));
            writer.Write((Int16)(symbol.RadiusMm * 100));
            writer.Write((UInt16)symbol.GridFlags);
            writer.Write((Int16)(symbol.CellWidthMm * 100));
            writer.Write((Int16)(symbol.CellHeightMm * 100));
            writer.Write(Writer.INT16_BLANK); // reserved0
            writer.Write(Writer.INT16_BLANK); // reserved1
            writer.Write(symbol.UnnumberedCells);
            writer.WritePascalString(symbol.UnnumberedCellsText, MAX_UNNUMBERED_CELLS_SIZE);
            writer.Write(Writer.INT16_BLANK); // reserved2
            writer.WritePascalString(String.Empty, MAX_RECTANGLE_RESERVED_SIZE); // reserved3
            writer.Write(Writer.INT16_BLANK); // reserved4
            writer.Write((Int16)(symbol.FontSize * 10));
            writer.Write(Writer.INT16_BLANK); // reserved6
            writer.WriteWordBoolean(false); // reserved7
            writer.Write(Writer.INT16_BLANK); // reserved8
            writer.Write(Writer.INT16_BLANK); // reserved9
        }
        #endregion
    }
}
