﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace Ocad.IO.Ocad9.Record.Helper
{
    internal partial class Setting
    {
        private const String EVENT_PARAMETER_CREATE_CLASSES_AUTOMATICALLY = "a";
        private const String EVENT_PARAMETER_WHITE_BACKGROUND_FOR_CONTROL_DESCRIPTION = "b";
        private const String EVENT_PARAMETER_NUMBERING = "c";
        private const String EVENT_PARAMETER_ADD_CONTROL_DESCRIPTIONS_FOR_ALL_CONTROLS = "d";
        private const String EVENT_PARAMETER_EVENT_TITLE = "e";
        private const String EVENT_PARAMETER_CONTROL_DESCRIPTION_HORIZTONAL_THICKER_LINE = "h";
        private const String EVENT_PARAMETER_CONTROL_DESCRIPTION_MAXIMUM_ROWS = "i";
        private const String EVENT_PARAMETER_DISTANCE_FROM_CIRCLE_TO_NUMBER_MM = "l";
        private const String EVENT_PARAMETER_DISTANCE_FROM_CIRCLE_TO_CONTROL_DESCRIPTION_MM = "n";
        private const String EVENT_PARAMETER_CONTROL_DESCRIPTION_BOX_SIZE_MM = "s";
        private const String EVENT_PARAMETER_COURSE_TITLE = "t";
        private const String EVENT_PARAMETER_EXPORT_RELAY_COMBINATION_IN_XML_FILE = "r";

        private void CopyToEventParameter(Model.Map map)
        {
            if (map.Event == null)
            {
                map.Event = new Event.Event();
            }
            Event.Parameter setting = new Event.Parameter();
            map.Event.Parameter = setting;

            int i = 0;
            while (i <= this.codeValue.GetUpperBound(0))
            {
                string code = this.codeValue[i, 0];
                switch (code)
                {
                    case EVENT_PARAMETER_CREATE_CLASSES_AUTOMATICALLY:
                        setting.CreateClassesAutomatically = this.codeValue[i, 1].Equals(TRUE);
                        break;
                    case EVENT_PARAMETER_WHITE_BACKGROUND_FOR_CONTROL_DESCRIPTION:
                        setting.WhiteBackgroundForControlDescription = this.codeValue[i, 1].Equals(TRUE);
                        break;
                    case EVENT_PARAMETER_NUMBERING:
                        setting.Numbering = (Event.Type.EventNumbering)Int32.Parse(this.codeValue[i, 1]);
                        break;
                    case EVENT_PARAMETER_ADD_CONTROL_DESCRIPTIONS_FOR_ALL_CONTROLS:
                        setting.AddControlDescriptionsForAllControls = this.codeValue[i, 1].Equals(TRUE);
                        break;
                    case EVENT_PARAMETER_EVENT_TITLE:
                        setting.EventTitle = this.codeValue[i, 1];
                        break;
                    case EVENT_PARAMETER_CONTROL_DESCRIPTION_HORIZTONAL_THICKER_LINE:
                        setting.ControlDescriptionHoriztonalThickerLine = (Event.Type.ControlDescriptionHoriztonalThickerLine)Int32.Parse(this.codeValue[i, 1]);
                        break;
                    case EVENT_PARAMETER_CONTROL_DESCRIPTION_MAXIMUM_ROWS:
                        setting.ControlDescriptionMaximumRows = Int32.Parse(this.codeValue[i, 1]);
                        break;
                    case EVENT_PARAMETER_DISTANCE_FROM_CIRCLE_TO_NUMBER_MM:
                        setting.DistanceFromCircleToNumberMm = Double.Parse(this.codeValue[i, 1]);
                        break;
                    case EVENT_PARAMETER_DISTANCE_FROM_CIRCLE_TO_CONTROL_DESCRIPTION_MM:
                        setting.DistanceFromCircleToConnectionLineMm = Double.Parse(this.codeValue[i, 1]);
                        break;
                    case EVENT_PARAMETER_CONTROL_DESCRIPTION_BOX_SIZE_MM:
                        setting.ControlDescriptionBoxSizeMm = Double.Parse(this.codeValue[i, 1]);
                        break;
                    case EVENT_PARAMETER_COURSE_TITLE:
                        setting.CourseTitle = (Event.Type.CourseTitle)Int32.Parse(this.codeValue[i, 1]);
                        break;
                    case EVENT_PARAMETER_EXPORT_RELAY_COMBINATION_IN_XML_FILE:
                        setting.ExportRelayCombinationInXmlFile = this.codeValue[i, 1].Equals(TRUE);
                        break;
                }
                i++;
            }
        }

        private static void CopyFromEventParameter(Model.Map map, List<Setting> settings)
        {
            Event.Parameter source = map.Event.Parameter;
            if (source != null)
            {
                Setting setting = new Setting();
                setting.SettingType = Type.SettingType.EventParameter;
                settings.Add(setting);

                StringBuilder b = new StringBuilder();
                if (source.CourseTitle.HasValue)
                {
                    b.AppendFormat("{0}{1}{2}", DELIMITATOR, EVENT_PARAMETER_COURSE_TITLE, (Int32)source.CourseTitle.Value);
                }
                if (source.Numbering.HasValue)
                {
                    b.AppendFormat("{0}{1}{2}", DELIMITATOR, EVENT_PARAMETER_NUMBERING, (Int32)source.Numbering.Value);
                }
                if (source.ControlDescriptionHoriztonalThickerLine.HasValue)
                {
                    b.AppendFormat("{0}{1}{2}", DELIMITATOR, EVENT_PARAMETER_CONTROL_DESCRIPTION_HORIZTONAL_THICKER_LINE, (Int32)source.ControlDescriptionHoriztonalThickerLine.Value);
                }
                if (source.ControlDescriptionMaximumRows.HasValue)
                {
                    b.AppendFormat("{0}{1}{2}", DELIMITATOR, EVENT_PARAMETER_CONTROL_DESCRIPTION_MAXIMUM_ROWS, source.ControlDescriptionMaximumRows.Value);
                }
                if (source.DistanceFromCircleToConnectionLineMm.HasValue)
                {
                    b.AppendFormat("{0}{1}{2:0.00}", DELIMITATOR, EVENT_PARAMETER_DISTANCE_FROM_CIRCLE_TO_CONTROL_DESCRIPTION_MM, source.DistanceFromCircleToConnectionLineMm.Value);
                }
                if (source.DistanceFromCircleToNumberMm.HasValue)
                {
                    b.AppendFormat("{0}{1}{2:0.00}", DELIMITATOR, EVENT_PARAMETER_DISTANCE_FROM_CIRCLE_TO_NUMBER_MM, source.DistanceFromCircleToNumberMm.Value);
                }
                if (source.ControlDescriptionBoxSizeMm.HasValue)
                {
                    b.AppendFormat("{0}{1}{2:0.00}", DELIMITATOR, EVENT_PARAMETER_CONTROL_DESCRIPTION_BOX_SIZE_MM, source.ControlDescriptionBoxSizeMm.Value);
                }
                if (source.WhiteBackgroundForControlDescription.HasValue)
                {
                    b.AppendFormat("{0}{1}{2}", DELIMITATOR, EVENT_PARAMETER_WHITE_BACKGROUND_FOR_CONTROL_DESCRIPTION, source.WhiteBackgroundForControlDescription.Value ? TRUE : FALSE);
                }
                if (source.AddControlDescriptionsForAllControls.HasValue)
                {
                    b.AppendFormat("{0}{1}{2}", DELIMITATOR, EVENT_PARAMETER_ADD_CONTROL_DESCRIPTIONS_FOR_ALL_CONTROLS, source.AddControlDescriptionsForAllControls.Value ? TRUE : FALSE);
                }
                if (source.ExportRelayCombinationInXmlFile.HasValue)
                {
                    b.AppendFormat("{0}{1}{2}", DELIMITATOR, EVENT_PARAMETER_EXPORT_RELAY_COMBINATION_IN_XML_FILE, source.ExportRelayCombinationInXmlFile.Value ? TRUE : FALSE);
                }
                if (source.CreateClassesAutomatically.HasValue)
                {
                    b.AppendFormat("{0}{1}{2}", DELIMITATOR, EVENT_PARAMETER_CREATE_CLASSES_AUTOMATICALLY, source.CreateClassesAutomatically.Value ? TRUE : FALSE);
                }
                if (source.EventTitle != null)
                {
                    b.AppendFormat("{0}{1}{2}", DELIMITATOR, EVENT_PARAMETER_EVENT_TITLE, source.EventTitle);
                }
                setting.ConcatenatedValues = b.ToString();
            }
        }
    }
}
