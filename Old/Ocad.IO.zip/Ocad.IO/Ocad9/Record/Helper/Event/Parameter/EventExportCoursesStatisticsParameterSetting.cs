﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace Ocad.IO.Ocad9.Record.Helper
{
    internal partial class Setting
    {
        /*
        [VersionsSupported(V9 = true)]
        public Type.CoursesOrClasses? CoursesOrClasses { get; set; }
        [VersionsSupported(V9 = true)]
        public String Separator1 { get; set; }
        [VersionsSupported(V9 = true)]
        public String Tab1 { get; set; }
        [VersionsSupported(V9 = true)]
        public String Separator2 { get; set; }
        [VersionsSupported(V9 = true)]
        public String Tab2 { get; set; }
        [VersionsSupported(V9 = true)]
        public String Separator3 { get; set; }
        [VersionsSupported(V9 = true)]
        public String Tab3 { get; set; }
         */
        private const String EVENT_EXPORT_COURSES_STATISTICS_PARAMETER_COURSES_OR_CLASSES = "C";
        private const String EVENT_EXPORT_COURSES_STATISTICS_PARAMETER_SEPARATOR_1 = "a";
        private const String EVENT_EXPORT_COURSES_STATISTICS_PARAMETER_TAB_1 = "b";
        private const String EVENT_EXPORT_COURSES_STATISTICS_PARAMETER_SEPARATOR_2 = "c";
        private const String EVENT_EXPORT_COURSES_STATISTICS_PARAMETER_TAB_2 = "d";
        private const String EVENT_EXPORT_COURSES_STATISTICS_PARAMETER_SEPARATOR_3 = "e";
        private const String EVENT_EXPORT_COURSES_STATISTICS_PARAMETER_TAB_3 = "f";

        private void CopyToEventExportCoursesStatisticsParameter(Model.Map map)
        {
            if (map.Event == null)
            {
                map.Event = new Event.Event();
            }
            Event.ExportCoursesStatisticsParameter setting = new Event.ExportCoursesStatisticsParameter();
            map.Event.ExportCoursesStatisticsParameter = setting;

            int i = 0;
            while (i <= this.codeValue.GetUpperBound(0))
            {
                string code = this.codeValue[i, 0];
                switch (code)
                {
                    case EVENT_EXPORT_COURSES_STATISTICS_PARAMETER_COURSES_OR_CLASSES:
                        setting.CoursesOrClasses = (Event.Type.CoursesOrClasses)Int32.Parse(this.codeValue[i, 1]);
                        break;
                    case EVENT_EXPORT_COURSES_STATISTICS_PARAMETER_SEPARATOR_1:
                        setting.Separator1 = this.codeValue[i, 1];
                        break;
                    case EVENT_EXPORT_COURSES_STATISTICS_PARAMETER_TAB_1:
                        setting.Tab1 = this.codeValue[i, 1];
                        break;
                    case EVENT_EXPORT_COURSES_STATISTICS_PARAMETER_SEPARATOR_2:
                        setting.Separator2 = this.codeValue[i, 1];
                        break;
                    case EVENT_EXPORT_COURSES_STATISTICS_PARAMETER_TAB_2:
                        setting.Tab2 = this.codeValue[i, 1];
                        break;
                    case EVENT_EXPORT_COURSES_STATISTICS_PARAMETER_SEPARATOR_3:
                        setting.Separator3 = this.codeValue[i, 1];
                        break;
                    case EVENT_EXPORT_COURSES_STATISTICS_PARAMETER_TAB_3:
                        setting.Tab3 = this.codeValue[i, 1];
                        break;
                }
                i++;
            }
        }

        private static void CopyFromEventExportCoursesStatisticsParameter(Model.Map map, List<Setting> settings)
        {
            Event.ExportCoursesStatisticsParameter source = map.Event.ExportCoursesStatisticsParameter;
            if (source != null)
            {
                Setting setting = new Setting();
                setting.SettingType = Type.SettingType.EventParameter;
                settings.Add(setting);

                StringBuilder b = new StringBuilder();
                if (source.CoursesOrClasses.HasValue)
                {
                    b.AppendFormat("{0}{1}{2}", DELIMITATOR, EVENT_EXPORT_COURSES_STATISTICS_PARAMETER_COURSES_OR_CLASSES, (Int32)source.CoursesOrClasses.Value);
                }
                if (source.Separator1 != null)
                {
                    b.AppendFormat("{0}{1}{2}", DELIMITATOR, EVENT_EXPORT_COURSES_STATISTICS_PARAMETER_SEPARATOR_1, source.Separator1);
                }
                if (source.Tab1 != null)
                {
                    b.AppendFormat("{0}{1}{2}", DELIMITATOR, EVENT_EXPORT_COURSES_STATISTICS_PARAMETER_TAB_1, source.Tab1);
                }
                if (source.Separator2 != null)
                {
                    b.AppendFormat("{0}{1}{2}", DELIMITATOR, EVENT_EXPORT_COURSES_STATISTICS_PARAMETER_SEPARATOR_2, source.Separator2);
                }
                if (source.Tab2 != null)
                {
                    b.AppendFormat("{0}{1}{2}", DELIMITATOR, EVENT_EXPORT_COURSES_STATISTICS_PARAMETER_TAB_2, source.Tab2);
                }
                if (source.Separator3 != null)
                {
                    b.AppendFormat("{0}{1}{2}", DELIMITATOR, EVENT_EXPORT_COURSES_STATISTICS_PARAMETER_SEPARATOR_3, source.Separator3);
                }
                if (source.Tab3 != null)
                {
                    b.AppendFormat("{0}{1}{2}", DELIMITATOR, EVENT_EXPORT_COURSES_STATISTICS_PARAMETER_TAB_3, source.Tab3);
                }
                setting.ConcatenatedValues = b.ToString();
            }
        }
    }
}
