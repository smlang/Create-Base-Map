﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace Ocad.IO.Ocad9.Record.Helper
{
    internal partial class Setting
    {
        private const String CLASS_COURSE_NAME = "c";
        private const String CLASS_NUMBER_OF_RUNNERS = "r";
        private const String CLASS_FROM_NUMBER = "f";
        private const String CLASS_TO_NUMBER = "t";

        private void CopyToEventClass(Model.Map map)
        {
            if (map.Event == null)
            {
                map.Event = new Event.Event();
            }
            Event.Class setting = new Event.Class();
            setting.Name = this.mainValue;

            int i = 0;
            while (i <= this.codeValue.GetUpperBound(0))
            {
                string code = this.codeValue[i, 0];
                switch (code)
                {
                    case CLASS_COURSE_NAME:
                        Event.Course.Course course = MapExtension.GetOrCreateEventCourse(map, this.codeValue[i, 1]);
                        course.Classes.Add(setting);
                        break;
                    case CLASS_NUMBER_OF_RUNNERS:
                        setting.NumberOfRunners = Int32.Parse(this.codeValue[i, 1]);
                        break;
                    case CLASS_FROM_NUMBER:
                        setting.FromBibNumber = Int32.Parse(this.codeValue[i, 1]);
                        break;
                    case CLASS_TO_NUMBER:
                        setting.ToBibNumber = Int32.Parse(this.codeValue[i, 1]);
                        break;
                }
                i++;
            }
        }

        private static void CopyFromEventClasses(Event.Course.Course course, List<Setting> settings)
        {
            foreach (Event.Class source in course.Classes)
            {
                Setting setting = new Setting();
                setting.SettingType = Type.SettingType.EventClass;
                settings.Add(setting);

                StringBuilder b = new StringBuilder(source.Name);

                b.AppendFormat("{0}{1}{2}", DELIMITATOR, CLASS_COURSE_NAME, course.Name);
                if (source.NumberOfRunners.HasValue)
                {
                    b.AppendFormat("{0}{1}{2}", DELIMITATOR, CLASS_NUMBER_OF_RUNNERS, source.NumberOfRunners.Value);
                }
                if (source.FromBibNumber.HasValue)
                {
                    b.AppendFormat("{0}{1}{2}", DELIMITATOR, CLASS_FROM_NUMBER, source.FromBibNumber.Value);
                }
                if (source.ToBibNumber.HasValue)
                {
                    b.AppendFormat("{0}{1}{2}", DELIMITATOR, CLASS_TO_NUMBER, source.ToBibNumber.Value);
                }

                setting.ConcatenatedValues = b.ToString();
            }
        }
    }
}
