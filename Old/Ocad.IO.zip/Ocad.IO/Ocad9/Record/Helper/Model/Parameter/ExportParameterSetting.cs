﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace Ocad.IO.Ocad9.Record.Helper
{
    internal partial class Setting
    {
        private const String EXPORT_PARAMETER_ANTI_ALIASING = "a";
        private const String EXPORT_PARAMETER_SPOT_COLOURS_COMBINED = "b";
        private const String EXPORT_PARAMETER_COLOUR_FORMAT = "c";
        private const String EXPORT_PARAMETER_COLOUR_CORRECTION = "l";
        private const String EXPORT_PARAMETER_SPOT_COLOURS = "o";
        private const String EXPORT_PARAMETER_PARTIAL_MAP = "p";
        private const String EXPORT_PARAMETER_RESOLUTION = "r";
        private const String EXPORT_PARAMETER_SCALE = "s";
        private const String EXPORT_PARAMETER_TILES = "t";
        private const String EXPORT_PARAMETER_Z = "z";

        private void CopyToModelExportParameter(Model.Map map)
        {
            Model.ExportParameter setting = new Model.ExportParameter();
            map.ExportParameter = setting;

            int i = 0;
            setting.Format = this.mainValue;
            while (i <= this.codeValue.GetUpperBound(0))
            {
                string code = this.codeValue[i, 0];
                switch (code)
                {
                    case EXPORT_PARAMETER_ANTI_ALIASING:
                        setting.AntiAliasing = this.codeValue[i, 1].Equals(TRUE);
                        break;
                    case EXPORT_PARAMETER_SPOT_COLOURS_COMBINED:
                        setting.SpotColoursCombined = this.codeValue[i, 1].Equals(TRUE);
                        break;
                    case EXPORT_PARAMETER_COLOUR_FORMAT:
                        setting.ColourFormat = (Model.Type.ColourFormat)Byte.Parse(this.codeValue[i, 1]);
                        break;
                    case EXPORT_PARAMETER_COLOUR_CORRECTION:
                        setting.ColourCorrection = this.codeValue[i, 1].Equals(TRUE);
                        break;
                    case EXPORT_PARAMETER_SPOT_COLOURS:
                        setting.SpotColours = this.codeValue[i, 1].Equals(TRUE);
                        break;
                    case EXPORT_PARAMETER_PARTIAL_MAP:
                        setting.PartialMap = this.codeValue[i, 1].Equals(TRUE);
                        break;
                    case EXPORT_PARAMETER_RESOLUTION:
                        setting.Resolution = Int16.Parse(this.codeValue[i, 1]);
                        break;
                    case EXPORT_PARAMETER_SCALE:
                        setting.Scale = this.codeValue[i, 1];
                        break;
                    case EXPORT_PARAMETER_TILES:
                        setting.Tiles = this.codeValue[i, 1].Equals(TRUE);
                        break;
                    case EXPORT_PARAMETER_Z:
                        setting.ZParameter = this.codeValue[i, 1];
                        break;
                }
                i++;
            }
        }

        private static void CopyFromModelExportParameter(Model.Map map, List<Setting> settings)
        {
            Model.ExportParameter source = map.ExportParameter;
            if (source != null)
            {
                Setting setting = new Setting();
                setting.SettingType = Type.SettingType.ExportParameter;
                settings.Add(setting);

                StringBuilder b = new StringBuilder(source.Format);
                if (source.AntiAliasing.HasValue)
                {
                    b.AppendFormat("{0}{1}{2}", DELIMITATOR, EXPORT_PARAMETER_ANTI_ALIASING, source.AntiAliasing.Value ? TRUE : FALSE);
                }
                if (source.SpotColoursCombined.HasValue)
                {
                    b.AppendFormat("{0}{1}{2}", DELIMITATOR, EXPORT_PARAMETER_SPOT_COLOURS_COMBINED, source.SpotColoursCombined.Value ? TRUE : FALSE);
                }
                if (source.ColourCorrection.HasValue)
                {
                    b.AppendFormat("{0}{1}{2}", DELIMITATOR, EXPORT_PARAMETER_COLOUR_CORRECTION, source.ColourCorrection.Value ? TRUE : FALSE);
                }
                if (source.ColourFormat.HasValue)
                {
                    b.AppendFormat("{0}{1}{2}", DELIMITATOR, EXPORT_PARAMETER_COLOUR_FORMAT, (Byte)source.ColourFormat.Value);
                }
                if (source.SpotColours.HasValue)
                {
                    b.AppendFormat("{0}{1}{2}", DELIMITATOR, EXPORT_PARAMETER_SPOT_COLOURS, source.SpotColours.Value ? TRUE : FALSE);
                }
                if (source.PartialMap.HasValue)
                {
                    b.AppendFormat("{0}{1}{2}", DELIMITATOR, EXPORT_PARAMETER_PARTIAL_MAP, source.PartialMap.Value ? TRUE : FALSE);
                }
                if (source.Resolution.HasValue)
                {
                    b.AppendFormat("{0}{1}{2}", DELIMITATOR, EXPORT_PARAMETER_RESOLUTION, source.Resolution.Value);
                }
                if (source.Tiles.HasValue)
                {
                    b.AppendFormat("{0}{1}{2}", DELIMITATOR, EXPORT_PARAMETER_TILES, source.Tiles.Value ? TRUE : FALSE);
                }
                if (source.ZParameter != null)
                {
                    b.AppendFormat("{0}{1}{2}", DELIMITATOR, EXPORT_PARAMETER_Z, source.ZParameter);
                }
                if (source.Scale != null)
                {
                    b.AppendFormat("{0}{1}{2}", DELIMITATOR, EXPORT_PARAMETER_SCALE, source.Scale);
                }

                setting.ConcatenatedValues = b.ToString();
            }
        }
    }
}
