﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace Ocad.IO.Ocad9.Record.Helper
{
    internal partial class Setting
    {
        private const String SCALE_PARAMETER_REAL_WORLD_ANGLE_CODE = "a";
        private const String SCALE_PARAMETER_REAL_WORLD_GRID_DISTANCE_M_CODE = "d";
        private const String SCALE_PARAMETER_PAPER_GRID_DISTANCE_MM_CODE = "g";
        private const String SCALE_PARAMETER_REAL_WORLD_COORDINATE_SYSTEM_CODE = "i";
        private const String SCALE_PARAMETER_MAP_SCALE_CODE = "m";
        private const String SCALE_PARAMETER_USE_REAL_WORLD_GRID_CODE = "r";
        private const String SCALE_PARAMETER_REAL_WORLD_OFFSET_X_CODE = "x";
        private const String SCALE_PARAMETER_REAL_WORLD_OFFSET_Y_CODE = "y";

        private void CopyToModelScaleParameter(Model.Map map)
        {
            Model.ScaleParameter setting = new Model.ScaleParameter();
            map.ScaleParameter = setting;

            int i = 0;
            while (i <= this.codeValue.GetUpperBound(0))
            {
                string code = this.codeValue[i, 0];
                switch (code)
                {
                    case SCALE_PARAMETER_MAP_SCALE_CODE:
                        setting.MapScale = Int32.Parse(this.codeValue[i, 1]);
                        break;
                    case SCALE_PARAMETER_PAPER_GRID_DISTANCE_MM_CODE:
                        setting.PaperGridDistanceMm = Double.Parse(this.codeValue[i, 1]);
                        break;
                    case SCALE_PARAMETER_USE_REAL_WORLD_GRID_CODE:
                        setting.UseRealWorldGrid = this.codeValue[i, 1].Equals(TRUE);
                        break;
                    case SCALE_PARAMETER_REAL_WORLD_OFFSET_X_CODE:
                        setting.RealWorldOffsetX = Int32.Parse(this.codeValue[i, 1]);
                        break;
                    case SCALE_PARAMETER_REAL_WORLD_OFFSET_Y_CODE:
                        setting.RealWorldOffsetY = Int32.Parse(this.codeValue[i, 1]);
                        break;
                    case SCALE_PARAMETER_REAL_WORLD_ANGLE_CODE:
                        setting.RealWorldAngle = Double.Parse(this.codeValue[i, 1]);
                        break;
                    case SCALE_PARAMETER_REAL_WORLD_GRID_DISTANCE_M_CODE:
                        setting.RealWorldGridDistanceM = Int32.Parse(this.codeValue[i, 1]);
                        break;
                    case SCALE_PARAMETER_REAL_WORLD_COORDINATE_SYSTEM_CODE:
                        setting.RealWorldCoordinateSystem = (Model.Type.CoordinateSystemType)Int32.Parse(this.codeValue[i, 1]);
                        break;
                }
                i++;
            }
        }

        private static void CopyFromModelScaleParameter(Model.Map map, List<Setting> settings)
        {
            Model.ScaleParameter source = map.ScaleParameter;
            if (source != null)
            {
                Setting setting = new Setting();
                setting.SettingType = Type.SettingType.ScaleParameter;
                settings.Add(setting);

                StringBuilder b = new StringBuilder();
                b.AppendFormat("{0}{1}{2}", DELIMITATOR, SCALE_PARAMETER_MAP_SCALE_CODE, source.MapScale);
                b.AppendFormat("{0}{1}{2:0.0000}", DELIMITATOR, SCALE_PARAMETER_PAPER_GRID_DISTANCE_MM_CODE, source.PaperGridDistanceMm);
                b.AppendFormat("{0}{1}{2}", DELIMITATOR, SCALE_PARAMETER_USE_REAL_WORLD_GRID_CODE, source.UseRealWorldGrid ? TRUE : FALSE);
                if (source.RealWorldOffsetX.HasValue)
                {
                    b.AppendFormat("{0}{1}{2}", DELIMITATOR, SCALE_PARAMETER_REAL_WORLD_OFFSET_X_CODE, source.RealWorldOffsetX.Value);
                }
                if (source.RealWorldOffsetY.HasValue)
                {
                    b.AppendFormat("{0}{1}{2}", DELIMITATOR, SCALE_PARAMETER_REAL_WORLD_OFFSET_Y_CODE, source.RealWorldOffsetY.Value);
                }
                if (source.RealWorldAngle.HasValue)
                {
                    b.AppendFormat("{0}{1}{2:0.00}", DELIMITATOR, SCALE_PARAMETER_REAL_WORLD_ANGLE_CODE, source.RealWorldAngle.Value);
                }
                if (source.RealWorldGridDistanceM.HasValue)
                {
                    b.AppendFormat("{0}{1}{2}", DELIMITATOR, SCALE_PARAMETER_REAL_WORLD_GRID_DISTANCE_M_CODE, source.RealWorldGridDistanceM.Value);
                }
                if (source.RealWorldCoordinateSystem.HasValue)
                {
                    b.AppendFormat("{0}{1}{2}", DELIMITATOR, SCALE_PARAMETER_REAL_WORLD_COORDINATE_SYSTEM_CODE, (Int32)source.RealWorldCoordinateSystem);
                }
                setting.ConcatenatedValues = b.ToString();
            }
        }
    }
}
