﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace Ocad.IO.Ocad9.Record.Helper
{
    internal partial class Setting
    {
        private const String PRINT_PARAMETER_PRINT_SCALE = "a";
        private const String PRINT_PARAMETER_LANDSCAPE = "l";
        private const String PRINT_PARAMETER_PRINT_SPOT_SEPARATION = "c";
        private const String PRINT_PARAMETER_PRINT_GRID = "g";
        private const String PRINT_PARAMETER_GRID_COLOUR = "d";
        private const String PRINT_PARAMETER_INTENSITY = "i";
        private const String PRINT_PARAMETER_WIDTH_FOR_LINES_AND_DOTS_PERCENTAGE = "w";
        private const String PRINT_PARAMETER_RANGE = "r";
        private const String PRINT_PARAMETER_PARTIAL_MAP_LEFT_MM = "L";
        private const String PRINT_PARAMETER_PARTIAL_MAP_BOTTOM_MM = "B";
        private const String PRINT_PARAMETER_PARTIAL_MAP_RIGHT_MM = "R";
        private const String PRINT_PARAMETER_PARTIAL_MAP_TOP_MM = "T";
        private const String PRINT_PARAMETER_HORIZONTAL_OVERLAP = "x";
        private const String PRINT_PARAMETER_VERTICAL_OVERLAP = "y";
        private const String PRINT_PARAMETER_HORIZONTAL_SCALE = "s";
        private const String PRINT_PARAMETER_VERTICAL_SCALE = "t";
 
        private void CopyToModelPrintParameter(Model.Map map)
        {
            Model.PrintParameter setting = new Model.PrintParameter();
            map.PrintParameter = setting;

            int i = 0;
            while (i <= this.codeValue.GetUpperBound(0))
            {
                string code = this.codeValue[i, 0];
                switch (code)
                {
                    case PRINT_PARAMETER_PRINT_SCALE:
                        setting.PrintScale = Double.Parse(this.codeValue[i, 1]);
                        break;
                    case PRINT_PARAMETER_LANDSCAPE:
                        setting.Landscape = this.codeValue[i, 1].Equals(TRUE);
                        break;
                    case PRINT_PARAMETER_PRINT_SPOT_SEPARATION:
                        setting.PrintSpotSeparation = this.codeValue[i, 1].Equals(TRUE);
                        break;
                    case PRINT_PARAMETER_PRINT_GRID:
                        setting.PrintGrid = this.codeValue[i, 1].Equals(TRUE);
                        break;
                    case PRINT_PARAMETER_GRID_COLOUR:
                        setting.GridColour = MapExtension.GetOrCreateColour(map, Int16.Parse(this.codeValue[i, 1]));
                        break;
                    case PRINT_PARAMETER_INTENSITY:
                        setting.Intensity = Byte.Parse(this.codeValue[i, 1]);
                        break;
                    case PRINT_PARAMETER_WIDTH_FOR_LINES_AND_DOTS_PERCENTAGE:
                        setting.WidthForLinesAndDotsPercentage = Byte.Parse(this.codeValue[i, 1]);
                        break;
                    case PRINT_PARAMETER_RANGE:
                        setting.Range = Byte.Parse(this.codeValue[i, 1]);
                        break;
                    case PRINT_PARAMETER_PARTIAL_MAP_LEFT_MM:
                        setting.PartialMapLeftMm = Double.Parse(this.codeValue[i, 1]);
                        break;
                    case PRINT_PARAMETER_PARTIAL_MAP_BOTTOM_MM:
                        setting.PartialMapBottomMm = Double.Parse(this.codeValue[i, 1]);
                        break;
                    case PRINT_PARAMETER_PARTIAL_MAP_RIGHT_MM:
                        setting.PartialMapRightMm = Double.Parse(this.codeValue[i, 1]);
                        break;
                    case PRINT_PARAMETER_PARTIAL_MAP_TOP_MM:
                        setting.PartialMapTopMm = Double.Parse(this.codeValue[i, 1]);
                        break;
                    case PRINT_PARAMETER_HORIZONTAL_OVERLAP:
                        setting.HorizontalOverlap = Double.Parse(this.codeValue[i, 1]);
                        break;
                    case PRINT_PARAMETER_VERTICAL_OVERLAP:
                        setting.VerticalOverlap = Double.Parse(this.codeValue[i, 1]);
                        break;
                    case PRINT_PARAMETER_HORIZONTAL_SCALE:
                        setting.HorizontalScale = Double.Parse(this.codeValue[i, 1]);
                        break;
                    case PRINT_PARAMETER_VERTICAL_SCALE:
                        setting.VerticalScale = Double.Parse(this.codeValue[i, 1]);
                        break;
                }
                i++;
            }
        }

        private static void CopyFromModelPrintParameter(Model.Map map, List<Setting> settings)
        {
            Model.PrintParameter source = map.PrintParameter;
            if (source != null)
            {
                Setting setting = new Setting();
                setting.SettingType = Type.SettingType.PrintParameter;
                settings.Add(setting);

                StringBuilder b = new StringBuilder();
                b.AppendFormat("{0}{1}{2:0.00}", DELIMITATOR, PRINT_PARAMETER_PRINT_SCALE, source.PrintScale);
                b.AppendFormat("{0}{1}{2:0.000000}", DELIMITATOR, PRINT_PARAMETER_PARTIAL_MAP_LEFT_MM, source.PartialMapLeftMm);
                b.AppendFormat("{0}{1}{2:0.000000}", DELIMITATOR, PRINT_PARAMETER_PARTIAL_MAP_BOTTOM_MM, source.PartialMapBottomMm);
                b.AppendFormat("{0}{1}{2:0.000000}", DELIMITATOR, PRINT_PARAMETER_PARTIAL_MAP_RIGHT_MM, source.PartialMapRightMm);
                b.AppendFormat("{0}{1}{2:0.000000}", DELIMITATOR, PRINT_PARAMETER_PARTIAL_MAP_TOP_MM, source.PartialMapTopMm);
                b.AppendFormat("{0}{1}{2:0.00}", DELIMITATOR, PRINT_PARAMETER_HORIZONTAL_OVERLAP, source.HorizontalOverlap);
                b.AppendFormat("{0}{1}{2:0.00}", DELIMITATOR, PRINT_PARAMETER_VERTICAL_OVERLAP, source.VerticalOverlap);
                b.AppendFormat("{0}{1}{2}", DELIMITATOR, PRINT_PARAMETER_PRINT_GRID, source.PrintGrid ? TRUE : FALSE);
                if (source.GridColour != null)
                {
                    b.AppendFormat("{0}{1}{2}", DELIMITATOR, PRINT_PARAMETER_GRID_COLOUR, source.GridColour.Number);
                }
                b.AppendFormat("{0}{1}{2}", DELIMITATOR, PRINT_PARAMETER_INTENSITY, source.Intensity);
                b.AppendFormat("{0}{1}{2}", DELIMITATOR, PRINT_PARAMETER_WIDTH_FOR_LINES_AND_DOTS_PERCENTAGE, source.WidthForLinesAndDotsPercentage);
                if (source.Landscape.HasValue)
                {
                    b.AppendFormat("{0}{1}{2}", DELIMITATOR, PRINT_PARAMETER_LANDSCAPE, source.Landscape.Value ? TRUE : FALSE);
                }
                if (source.PrintSpotSeparation.HasValue)
                {
                    b.AppendFormat("{0}{1}{2}", DELIMITATOR, PRINT_PARAMETER_PRINT_SPOT_SEPARATION, source.PrintSpotSeparation.Value ? TRUE : FALSE);
                }
                if (source.Range.HasValue)
                {
                    b.AppendFormat("{0}{1}{2}", DELIMITATOR, PRINT_PARAMETER_RANGE, source.Range.Value);
                }
                if (source.HorizontalScale.HasValue)
                {
                    b.AppendFormat("{0}{1}{2:0.0}", DELIMITATOR, PRINT_PARAMETER_HORIZONTAL_SCALE, source.HorizontalScale.Value);
                }
                if (source.VerticalScale.HasValue)
                {
                    b.AppendFormat("{0}{1}{2:0.0}", DELIMITATOR, PRINT_PARAMETER_VERTICAL_SCALE, source.VerticalScale.Value);
                }

                setting.ConcatenatedValues = b.ToString();
            }
        }
    }
}
