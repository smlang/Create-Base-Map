﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace Ocad.IO.Ocad9.Record.Helper
{
    internal partial class Setting
    {
        private const String DATABASE_CREATE_OBJECT_PARAMETER_CONDITION = "c";
        private const String DATABASE_CREATE_OBJECT_PARAMETER_DATA_SET = "d";
        private const String DATABASE_CREATE_OBJECT_PARAMETER_TEXT_FIELD = "t";
        private const String DATABASE_CREATE_OBJECT_PARAMETER_UNIT_OF_MEASURE = "m";
        private const String DATABASE_CREATE_OBJECT_PARAMETER_HORIZONTAL_OFFSET = "u";
        private const String DATABASE_CREATE_OBJECT_PARAMETER_VERTICAL_OFFSET = "v";
        private const String DATABASE_CREATE_OBJECT_PARAMETER_HORIZONTAL_FIELD = "x";
        private const String DATABASE_CREATE_OBJECT_PARAMETER_VERTICAL_FIELD = "y";

        private void CopyToModelDatabaseCreateObjectParameter(Model.Map map)
        {
            Model.DatabaseCreateObjectParameter setting = new Model.DatabaseCreateObjectParameter();
            map.DatabaseCreateObjectParameter = setting;

            int i = 0;
            while (i <= this.codeValue.GetUpperBound(0))
            {
                string code = this.codeValue[i, 0];
                switch (code)
                {
                    case DATABASE_CREATE_OBJECT_PARAMETER_CONDITION:
                        setting.Condition = this.codeValue[i, 1];
                        break;
                    case DATABASE_CREATE_OBJECT_PARAMETER_DATA_SET:
                        setting.DataSet = this.codeValue[i, 1];
                        break;
                    case DATABASE_CREATE_OBJECT_PARAMETER_TEXT_FIELD:
                        setting.TextField = this.codeValue[i, 1];
                        break;
                    case DATABASE_CREATE_OBJECT_PARAMETER_UNIT_OF_MEASURE:
                        setting.UnitOfMeasure = this.codeValue[i, 1];
                        break;
                    case DATABASE_CREATE_OBJECT_PARAMETER_HORIZONTAL_OFFSET:
                        setting.HorizontalOffset = this.codeValue[i, 1];
                        break;
                    case DATABASE_CREATE_OBJECT_PARAMETER_VERTICAL_OFFSET:
                        setting.VerticalOffset = this.codeValue[i, 1];
                        break;
                    case DATABASE_CREATE_OBJECT_PARAMETER_HORIZONTAL_FIELD:
                        setting.HorizontalField = this.codeValue[i, 1];
                        break;
                    case DATABASE_CREATE_OBJECT_PARAMETER_VERTICAL_FIELD:
                        setting.VerticalField = this.codeValue[i, 1];
                        break;
                }
                i++;
            }
        }

        private static void CopyFromModelDatabaseCreateObjectParameter(Model.Map map, List<Setting> settings)
        {
            Model.DatabaseCreateObjectParameter source = map.DatabaseCreateObjectParameter;
            if (source != null)
            {
                Setting setting = new Setting();
                setting.SettingType = Type.SettingType.DatabaseCreateObjectParameter;
                settings.Add(setting);

                StringBuilder b = new StringBuilder();
                if (source.Condition != null)
                {
                    b.AppendFormat("{0}{1}{2}", DELIMITATOR, DATABASE_CREATE_OBJECT_PARAMETER_CONDITION, source.Condition);
                }
                if (source.DataSet != null)
                {
                    b.AppendFormat("{0}{1}{2}", DELIMITATOR, DATABASE_CREATE_OBJECT_PARAMETER_DATA_SET, source.DataSet);
                }
                if (source.TextField != null)
                {
                    b.AppendFormat("{0}{1}{2}", DELIMITATOR, DATABASE_CREATE_OBJECT_PARAMETER_TEXT_FIELD, source.TextField);
                }
                if (source.UnitOfMeasure != null)
                {
                    b.AppendFormat("{0}{1}{2}", DELIMITATOR, DATABASE_CREATE_OBJECT_PARAMETER_UNIT_OF_MEASURE, source.UnitOfMeasure);
                }
                if (source.HorizontalOffset != null)
                {
                    b.AppendFormat("{0}{1}{2}", DELIMITATOR, DATABASE_CREATE_OBJECT_PARAMETER_HORIZONTAL_OFFSET, source.HorizontalOffset);
                }
                if (source.VerticalOffset != null)
                {
                    b.AppendFormat("{0}{1}{2}", DELIMITATOR, DATABASE_CREATE_OBJECT_PARAMETER_VERTICAL_OFFSET, source.VerticalOffset);
                }
                if (source.HorizontalField != null)
                {
                    b.AppendFormat("{0}{1}{2}", DELIMITATOR, DATABASE_CREATE_OBJECT_PARAMETER_HORIZONTAL_FIELD, source.HorizontalField);
                }
                if (source.VerticalField != null)
                {
                    b.AppendFormat("{0}{1}{2}", DELIMITATOR, DATABASE_CREATE_OBJECT_PARAMETER_VERTICAL_FIELD, source.VerticalField);
                }

                setting.ConcatenatedValues = b.ToString();
            }
        }
    }
}
