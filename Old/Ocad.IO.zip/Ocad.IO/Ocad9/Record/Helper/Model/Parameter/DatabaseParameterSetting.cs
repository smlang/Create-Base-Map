﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace Ocad.IO.Ocad9.Record.Helper
{
    internal partial class Setting
    {
        private const String DATABASE_PARAMETER_DATA_SET = "d";
        private const String DATABASE_PARAMETER_LAST_CODE = "l";
        private const String DATABASE_PARAMETER_CREATE_NEW_RECORD = "n";

        private void CopyToModelDatabaseParameter(Model.Map map)
        {
            Model.DatabaseParameter setting = new Model.DatabaseParameter();
            map.DatabaseParameter = setting;

            int i = 0;
            while (i <= this.codeValue.GetUpperBound(0))
            {
                string code = this.codeValue[i, 0];
                switch (code)
                {
                    case DATABASE_PARAMETER_DATA_SET:
                        setting.DataSet = this.codeValue[i, 1];
                        break;
                    case DATABASE_PARAMETER_LAST_CODE:
                        setting.LastCode = this.codeValue[i, 1];
                        break;
                    case DATABASE_PARAMETER_CREATE_NEW_RECORD:
                        setting.CreateNewRecord = this.codeValue[i, 1];
                        break;
                }
                i++;
            }
        }

        private static void CopyFromModelDatabaseParameter(Model.Map map, List<Setting> settings)
        {
            Model.DatabaseParameter source = map.DatabaseParameter;
            if (source != null)
            {
                Setting setting = new Setting();
                setting.SettingType = Type.SettingType.DatabaseParameter;
                settings.Add(setting);

                StringBuilder b = new StringBuilder();
                if (source.DataSet != null)
                {
                    b.AppendFormat("{0}{1}{2}", DELIMITATOR, DATABASE_PARAMETER_DATA_SET, source.DataSet);
                }
                if (source.LastCode != null)
                {
                    b.AppendFormat("{0}{1}{2}", DELIMITATOR, DATABASE_PARAMETER_LAST_CODE, source.LastCode);
                }
                if (source.CreateNewRecord != null)
                {
                    b.AppendFormat("{0}{1}{2}", DELIMITATOR, DATABASE_PARAMETER_CREATE_NEW_RECORD, source.CreateNewRecord);
                }

                setting.ConcatenatedValues = b.ToString();
            }
        }
    }
}
