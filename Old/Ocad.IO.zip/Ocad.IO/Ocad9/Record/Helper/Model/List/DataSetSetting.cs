﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace Ocad.IO.Ocad9.Record.Helper
{
    internal partial class Setting
    {
        private const String DATA_SET_DBASE_FILE = "e";
        private const String DATA_SET_ODBC_DATA_SOURCE = "d";
        private const String DATA_SET_TABLE = "t";
        private const String DATA_SET_KEY_FIELD = "k";
        private const String DATA_SET_SYMBOL_FIELD = "y";
        private const String DATA_SET_TEXT_FIELD = "x";
        private const String DATA_SET_SIZE_FIELD = "f";
        private const String DATA_SET_LENGTH_UNIT = "l";
        private const String DATA_SET_AREA_UNIT = "a";
        private const String DATA_SET_DECIMALS = "c";
        private const String DATA_SET_HORIZONTAL_COORDINATE = "h";
        private const String DATA_SET_VERTICAL_COORDINATE = "v";

        private void CopyToModelDataSet(Model.Map map)
        {
            Model.DataSet setting = new Model.DataSet();
            map.DataSets.Add(setting);

            setting.DataSetName = this.mainValue;

            int i = 0;
            while (i <= this.codeValue.GetUpperBound(0))
            {
                string code = this.codeValue[i, 0];
                switch (code)
                {
                    case DATA_SET_DBASE_FILE:
                        setting.DBaseFile = this.codeValue[i, 1];
                        break;
                    case DATA_SET_ODBC_DATA_SOURCE:
                        setting.OdbcDataSource = this.codeValue[i, 1];
                        break;
                    case DATA_SET_TABLE:
                        setting.Table = this.codeValue[i, 1];
                        break;
                    case DATA_SET_KEY_FIELD:
                        setting.KeyField = this.codeValue[i, 1];
                        break;
                    case DATA_SET_SYMBOL_FIELD:
                        setting.SymbolField = this.codeValue[i, 1];
                        break;
                    case DATA_SET_TEXT_FIELD:
                        setting.TextField = this.codeValue[i, 1];
                        break;
                    case DATA_SET_SIZE_FIELD:
                        setting.SizeField = this.codeValue[i, 1];
                        break;
                    case DATA_SET_LENGTH_UNIT:
                        setting.LengthUnit = this.codeValue[i, 1];
                        break;
                    case DATA_SET_AREA_UNIT:
                        setting.AreaUnit = this.codeValue[i, 1];
                        break;
                    case DATA_SET_DECIMALS:
                        setting.Decimals = this.codeValue[i, 1];
                        break;
                    case DATA_SET_HORIZONTAL_COORDINATE:
                        setting.HorizontalCoordinate = this.codeValue[i, 1];
                        break;
                    case DATA_SET_VERTICAL_COORDINATE:
                        setting.VerticalCoordinate = this.codeValue[i, 1];
                        break;
                }
                i++;
            }
        }

        private static void CopyFromModelDataSets(Model.Map map, List<Setting> settings)
        {
            foreach (Model.DataSet source in map.DataSets)
            {
                Setting setting = new Setting();
                setting.SettingType = Type.SettingType.DataSet;
                settings.Add(setting);

                StringBuilder b = new StringBuilder(source.DataSetName);
                if (source.DBaseFile != null)
                {
                    b.AppendFormat("{0}{1}{2}", DELIMITATOR, DATA_SET_DBASE_FILE, source.DBaseFile);
                }
                if (source.OdbcDataSource != null)
                {
                    b.AppendFormat("{0}{1}{2}", DELIMITATOR, DATA_SET_ODBC_DATA_SOURCE, source.OdbcDataSource);
                }
                if (source.Table != null)
                {
                    b.AppendFormat("{0}{1}{2}", DELIMITATOR, DATA_SET_TABLE, source.Table);
                }
                if (source.KeyField != null)
                {
                    b.AppendFormat("{0}{1}{2}", DELIMITATOR, DATA_SET_KEY_FIELD, source.KeyField);
                }
                if (source.SymbolField != null)
                {
                    b.AppendFormat("{0}{1}{2}", DELIMITATOR, DATA_SET_SYMBOL_FIELD, source.SymbolField);
                }
                if (source.TextField != null)
                {
                    b.AppendFormat("{0}{1}{2}", DELIMITATOR, DATA_SET_TEXT_FIELD, source.TextField);
                }
                if (source.SizeField != null)
                {
                    b.AppendFormat("{0}{1}{2}", DELIMITATOR, DATA_SET_SIZE_FIELD, source.SizeField);
                }
                if (source.LengthUnit != null)
                {
                    b.AppendFormat("{0}{1}{2}", DELIMITATOR, DATA_SET_LENGTH_UNIT, source.LengthUnit);
                }
                if (source.AreaUnit != null)
                {
                    b.AppendFormat("{0}{1}{2}", DELIMITATOR, DATA_SET_AREA_UNIT, source.AreaUnit);
                }
                if (source.Decimals != null)
                {
                    b.AppendFormat("{0}{1}{2}", DELIMITATOR, DATA_SET_DECIMALS, source.Decimals);
                }
                if (source.HorizontalCoordinate != null)
                {
                    b.AppendFormat("{0}{1}{2}", DELIMITATOR, DATA_SET_HORIZONTAL_COORDINATE, source.HorizontalCoordinate);
                }
                if (source.VerticalCoordinate != null)
                {
                    b.AppendFormat("{0}{1}{2}", DELIMITATOR, DATA_SET_VERTICAL_COORDINATE, source.VerticalCoordinate);
                }


                setting.ConcatenatedValues = b.ToString();
            }
        }
    }
}
