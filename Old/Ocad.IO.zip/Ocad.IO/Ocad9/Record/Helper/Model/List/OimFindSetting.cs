﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace Ocad.IO.Ocad9.Record.Helper
{
    internal partial class Setting
    {
        private const String OIM_FIND_CONDITION = "c";
        private const String OIM_FIND_DATA_SET = "d";
        private const String OIM_FIND_FROM_ZOOM = "f";
        private const String OIM_FIND_HINT_FIELD = "h";
        private const String OIM_FIND_NAME_FIELD = "n";
        private const String OIM_FIND_LIST_NAMES = "l";
        private const String OIM_FIND_HOTSPOT_TYPE = "o";
        private const String OIM_FIND_POINTER_TYPE = "p";
        private const String OIM_FIND_SHOW_HOTSPOTS = "s";
        private const String OIM_FIND_TO_ZOOM = "t";
        private const String OIM_FIND_URL_FIELD = "u";
        private const String OIM_FIND_PREFIX = "x";
        private const String OIM_FIND_POSTFIX = "y";
        private const String OIM_FIND_TARGET = "z";
        private const String OIM_FIND_POINTER_COLOUR_RED = "r";
        private const String OIM_FIND_POINTER_COLOUR_GREEN = "g";
        private const String OIM_FIND_POINTER_COLOUR_BLUE = "b";
        private const String OIM_FIND_HOTSPOT_COLOUR_RED = "R";
        private const String OIM_FIND_HOTSPOT_COLOUR_GREEN = "G";
        private const String OIM_FIND_HOTSPOT_COLOUR_BLUE = "B";

        private void CopyToModelOimFind(Model.Map map)
        {
            Model.OimFind setting = new Model.OimFind();
            map.OimFinds.Add(setting);

            setting.Name = this.mainValue;

            int i = 0;
            while (i <= this.codeValue.GetUpperBound(0))
            {
                string code = this.codeValue[i, 0];
                switch (code)
                {
                    case OIM_FIND_CONDITION:
                        setting.Condition = this.codeValue[i, 1];
                        break;
                    case OIM_FIND_DATA_SET:
                        setting.DataSet = this.codeValue[i, 1];
                        break;
                    case OIM_FIND_FROM_ZOOM:
                        setting.FromZoom = this.codeValue[i, 1];
                        break;
                    case OIM_FIND_HINT_FIELD:
                        setting.HintField = this.codeValue[i, 1];
                        break;
                    case OIM_FIND_NAME_FIELD:
                        setting.NameField = this.codeValue[i, 1];
                        break;
                    case OIM_FIND_LIST_NAMES:
                        setting.ListNames = this.codeValue[i, 1];
                        break;
                    case OIM_FIND_HOTSPOT_TYPE:
                        setting.HotspotType = this.codeValue[i, 1];
                        break;
                    case OIM_FIND_POINTER_TYPE:
                        setting.PointerType = this.codeValue[i, 1];
                        break;
                    case OIM_FIND_SHOW_HOTSPOTS:
                        setting.ShowHotspots = this.codeValue[i, 1];
                        break;
                    case OIM_FIND_TO_ZOOM:
                        setting.ToZoom = this.codeValue[i, 1];
                        break;
                    case OIM_FIND_URL_FIELD:
                        setting.UrlField = this.codeValue[i, 1];
                        break;
                    case OIM_FIND_PREFIX:
                        setting.Prefix = this.codeValue[i, 1];
                        break;
                    case OIM_FIND_POSTFIX:
                        setting.Postfix = this.codeValue[i, 1];
                        break;
                    case OIM_FIND_TARGET:
                        setting.Target = this.codeValue[i, 1];
                        break;
                    case OIM_FIND_POINTER_COLOUR_RED:
                        setting.PointerColourRed = this.codeValue[i, 1];
                        break;
                    case OIM_FIND_POINTER_COLOUR_GREEN:
                        setting.PointerColourBlue = this.codeValue[i, 1];
                        break;
                    case OIM_FIND_POINTER_COLOUR_BLUE:
                        setting.PointerColourGreen = this.codeValue[i, 1];
                        break;
                    case OIM_FIND_HOTSPOT_COLOUR_RED:
                        setting.HotspotColourRed = this.codeValue[i, 1];
                        break;
                    case OIM_FIND_HOTSPOT_COLOUR_GREEN:
                        setting.HotspotColourGreen = this.codeValue[i, 1];
                        break;
                    case OIM_FIND_HOTSPOT_COLOUR_BLUE:
                        setting.HotspotColourBlue = this.codeValue[i, 1];
                        break;
                }
                i++;
            }
        }

        private static void CopyFromModelOimFinds(Model.Map map, List<Setting> settings)
        {
            foreach (Model.OimFind source in map.OimFinds)
            {
                Setting setting = new Setting();
                setting.SettingType = Type.SettingType.OimFind;
                settings.Add(setting);

                StringBuilder b = new StringBuilder(source.Name);
                if (source.Condition != null)
                {
                    b.AppendFormat("{0}{1}{2}", DELIMITATOR, OIM_FIND_CONDITION, source.Condition);
                }
                if (source.DataSet != null)
                {
                    b.AppendFormat("{0}{1}{2}", DELIMITATOR, OIM_FIND_DATA_SET, source.DataSet);
                }
                if (source.FromZoom != null)
                {
                    b.AppendFormat("{0}{1}{2}", OIM_FIND_FROM_ZOOM, OIM_FIND_CONDITION, source.FromZoom);
                }
                if (source.HintField != null)
                {
                    b.AppendFormat("{0}{1}{2}", DELIMITATOR, OIM_FIND_HINT_FIELD, source.HintField);
                }
                if (source.NameField != null)
                {
                    b.AppendFormat("{0}{1}{2}", DELIMITATOR, OIM_FIND_NAME_FIELD, source.NameField);
                }
                if (source.ListNames != null)
                {
                    b.AppendFormat("{0}{1}{2}", DELIMITATOR, OIM_FIND_LIST_NAMES, source.ListNames);
                }
                if (source.HotspotType != null)
                {
                    b.AppendFormat("{0}{1}{2}", DELIMITATOR, OIM_FIND_HOTSPOT_TYPE, source.HotspotType);
                }
                if (source.PointerType != null)
                {
                    b.AppendFormat("{0}{1}{2}", DELIMITATOR, OIM_FIND_POINTER_TYPE, source.PointerType);
                }
                if (source.ShowHotspots != null)
                {
                    b.AppendFormat("{0}{1}{2}", DELIMITATOR, OIM_FIND_SHOW_HOTSPOTS, source.ShowHotspots);
                }
                if (source.ToZoom != null)
                {
                    b.AppendFormat("{0}{1}{2}", DELIMITATOR, OIM_FIND_TO_ZOOM, source.ToZoom);
                }
                if (source.UrlField != null)
                {
                    b.AppendFormat("{0}{1}{2}", DELIMITATOR, OIM_FIND_URL_FIELD, source.UrlField);
                }
                if (source.Prefix != null)
                {
                    b.AppendFormat("{0}{1}{2}", DELIMITATOR, OIM_FIND_PREFIX, source.Prefix);
                }
                if (source.Postfix != null)
                {
                    b.AppendFormat("{0}{1}{2}", DELIMITATOR, OIM_FIND_POSTFIX, source.Postfix);
                }
                if (source.Target != null)
                {
                    b.AppendFormat("{0}{1}{2}", DELIMITATOR, OIM_FIND_TARGET, source.Target);
                }
                if (source.PointerColourRed != null)
                {
                    b.AppendFormat("{0}{1}{2}", DELIMITATOR, OIM_FIND_POINTER_COLOUR_RED, source.PointerColourRed);
                }
                if (source.PointerColourGreen != null)
                {
                    b.AppendFormat("{0}{1}{2}", DELIMITATOR, OIM_FIND_POINTER_COLOUR_GREEN, source.PointerColourGreen);
                }
                if (source.PointerColourBlue != null)
                {
                    b.AppendFormat("{0}{1}{2}", DELIMITATOR, OIM_FIND_POINTER_COLOUR_BLUE, source.PointerColourBlue);
                }
                if (source.HotspotColourRed != null)
                {
                    b.AppendFormat("{0}{1}{2}", DELIMITATOR, OIM_FIND_HOTSPOT_COLOUR_RED, source.HotspotColourRed);
                }
                if (source.HotspotColourGreen != null)
                {
                    b.AppendFormat("{0}{1}{2}", DELIMITATOR, OIM_FIND_HOTSPOT_COLOUR_GREEN, source.HotspotColourGreen);
                }
                if (source.HotspotColourBlue != null)
                {
                    b.AppendFormat("{0}{1}{2}", DELIMITATOR, OIM_FIND_HOTSPOT_COLOUR_BLUE, source.HotspotColourBlue);
                }

                setting.ConcatenatedValues = b.ToString();
            }
        }
    }
}
