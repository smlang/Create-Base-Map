﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace Ocad.IO.Ocad9.Record.Helper
{
    internal partial class Setting
    {
        private const String IMPORT_LAYER_NUMBER = "n";

        private void CopyToModelImportLayer(Model.Map map)
        {
            Int16 number = 0;
            int i = 0;
            int numberIndex = -1;
            while ((i <= this.codeValue.GetUpperBound(0)) && (numberIndex < 0))
            {
                string code = this.codeValue[i, 0];
                switch (code)
                {
                    case IMPORT_LAYER_NUMBER:
                        number = Int16.Parse(this.codeValue[i, 1]);
                        numberIndex = i;
                        break;
                }
                i++;
            }

            Model.ImportLayer setting = MapExtension.GetOrCreateImportLayer(map, number, true);
            setting.LayerName = this.mainValue;
        }

        private static void CopyFromModelImportLayers(Model.Map map, List<Setting> settings)
        {
            foreach (Model.ImportLayer source in map.ImportLayers)
            {
                Setting setting = new Setting();
                setting.SettingType = Type.SettingType.ImportLayer;
                settings.Add(setting);

                StringBuilder b = new StringBuilder(source.LayerName);
                b.AppendFormat("{0}{1}{2}", DELIMITATOR, IMPORT_LAYER_NUMBER, source.LayerNumber);

                setting.ConcatenatedValues = b.ToString();
            }
        }
    }
}
