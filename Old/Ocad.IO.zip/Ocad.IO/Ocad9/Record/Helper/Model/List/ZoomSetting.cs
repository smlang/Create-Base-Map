﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace Ocad.IO.Ocad9.Record.Helper
{
    internal partial class Setting
    {
        private const String ZOOM_OFFSET_CENTRE_X_MM = "x";
        private const String ZOOM_OFFSET_CENTRE_Y_MM = "y";
        private const String ZOOM_DEPTH = "z";

        private void CopyToModelZoom(Model.Map map)
        {
            Model.Zoom setting = new Model.Zoom();
            map.Zooms.Add(setting);

            int i = 0;
            while (i <= this.codeValue.GetUpperBound(0))
            {
                string code = this.codeValue[i, 0];
                switch (code)
                {
                    case ZOOM_OFFSET_CENTRE_X_MM:
                        setting.OffsetCentreXMm = Double.Parse(this.codeValue[i, 1]);
                        break;
                    case ZOOM_OFFSET_CENTRE_Y_MM:
                        setting.OffsetCentreYMm = Double.Parse(this.codeValue[i, 1]);
                        break;
                    case ZOOM_DEPTH:
                        setting.Depth = Double.Parse(this.codeValue[i, 1]);
                        break;
                }
                i++;
            }
        }

        private static void CopyFromModelZooms(Model.Map map, List<Setting> settings)
        {
            foreach (Model.Zoom source in map.Zooms)
            {
                Setting setting = new Setting();
                setting.SettingType = Type.SettingType.Zoom;
                settings.Add(setting);

                StringBuilder b = new StringBuilder();
                b.AppendFormat("{0}{1}{2:0.000000}", DELIMITATOR, ZOOM_OFFSET_CENTRE_X_MM, source.OffsetCentreXMm);
                b.AppendFormat("{0}{1}{2:0.000000}", DELIMITATOR, ZOOM_OFFSET_CENTRE_Y_MM, source.OffsetCentreYMm);
                b.AppendFormat("{0}{1}{2:0.000000}", DELIMITATOR, ZOOM_DEPTH, source.Depth);

                setting.ConcatenatedValues = b.ToString();
            }
        }
    }
}
