﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace Ocad.IO.Ocad9.Record.Helper
{
    internal partial class Setting
    {
        internal const Char DELIMITATOR = '\t';
        internal const String TRUE = "1";
        internal const String FALSE = "0";

        internal Type.SettingType SettingType { get; set; }
        internal Int32 ModelObjectIndex { get; set; }
        internal String ConcatenatedValues { get; set; }

        private String mainValue;
        private String[,] codeValue;

        internal void CopyToModel(Model.Map map)
        {
            String[] parts = ConcatenatedValues.Split(Setting.DELIMITATOR);

            mainValue = parts[0];
            codeValue = new String[parts.Length - 1, 2];
            for (Int32 i = 1; i < parts.Length; i++)
            {
                codeValue[i - 1, 0] = parts[i][0].ToString();
                codeValue[i - 1, 1] = parts[i].Substring(1);
            }

            switch (SettingType)
            {
                case Type.SettingType.EventObject:
                    CopyToEventObject(map);
                    break;
                case Type.SettingType.EventCourse:
                    CopyToEventCourse(map);
                    break;
                case Type.SettingType.EventClass:
                    CopyToEventClass(map);
                    break;
                case Type.SettingType.EventPreviewObject:
                    CopyToEventPreviewObject(map);
                    break;


                case Type.SettingType.EventControlDescriptionPrintParameter:
                    CopyToEventControlDescriptionPrintParameter(map);
                    break;
                case Type.SettingType.EventParameter:
                    CopyToEventParameter(map);
                    break;
                case Type.SettingType.EventExportCoursesTextParameter:
                    CopyToEventExportCoursesTextParameter(map);
                    break;
                case Type.SettingType.EventExportCoursesStatisticsParameter:
                    CopyToEventExportCoursesStatisticsParameter(map);
                    break;

                
                case Type.SettingType.DataSet:
                    CopyToModelDataSet(map);
                    break;
                case Type.SettingType.DatabaseObject:
                    CopyToModelDatabaseObject(map);
                    break;
                case Type.SettingType.OimFile:
                    CopyToModelOimFile(map);
                    break;
                case Type.SettingType.Template:
                    CopyToModelTemplate(map);
                    break;
                case Type.SettingType.Colour:
                    CopyToModelColour(map);
                    break;
                case Type.SettingType.SpotColour:
                    CopyToModelSpotColour(map);
                    break;
                case Type.SettingType.FileInfo:
                    CopyToModelFileInfo(map);
                    break;
                case Type.SettingType.Zoom:
                    CopyToModelZoom(map);
                    break;
                case Type.SettingType.ImportLayer:
                    CopyToModelImportLayer(map);
                    break;
                case Type.SettingType.OimFind:
                    CopyToModelOimFind(map);
                    break;
                case Type.SettingType.SymbolTree:
                    CopyToModelSymbolTree(map);
                    break;


                case Type.SettingType.DisplayParameter:
                    CopyToModelDisplayParameter(map);
                    break;
                case Type.SettingType.OimParameter:
                    CopyToModelOimParameter(map);
                    break;
                case Type.SettingType.PrintParameter:
                    CopyToModelPrintParameter(map);
                    break;
                case Type.SettingType.TemplateParameter:
                    CopyToModelTemplateParameter(map);
                    break;
                case Type.SettingType.EpsParameter:
                    CopyToModelEpsParameter(map);
                    break;
                case Type.SettingType.ViewParameter:
                    CopyToModelViewParameter(map);
                    break;
                case Type.SettingType.TiffParameter:
                    CopyToModelTiffParameter(map);
                    break;
                case Type.SettingType.TilesParameter:
                    CopyToModelTilesParameter(map);
                    break;
                case Type.SettingType.DatabaseParameter:
                    CopyToModelDatabaseParameter(map);
                    break;
                case Type.SettingType.ExportParameter:
                    CopyToModelExportParameter(map);
                    break;
                case Type.SettingType.ScaleParameter:
                    CopyToModelScaleParameter(map);
                    break;
                case Type.SettingType.DatabaseCreateObjectParameter:
                    CopyToModelDatabaseCreateObjectParameter(map);
                    break;
                case Type.SettingType.SelectedSpotColoursParameter:
                    CopyToModelSelectedSpotColoursParameter(map);
                    break;
                case Type.SettingType.XmlScriptParameter:
                    CopyToModelXmlScriptParameter(map);
                    break;
                default:
                    CopyToModelMiscellaneous(map);
                    break;
            }
        }

        internal static List<Setting> CopyFromModel(Model.Map map)
        {
            List<Setting> settings = new List<Setting>();

            if (map.Event != null)
            {
                CopyFromEventObjects(map, settings);
                CopyFromEventCourses(map, settings);
                CopyFromEventPreviewObjects(map, settings);

                CopyFromEventControlDescriptionPrintParameter(map, settings);
                CopyFromEventParameter(map, settings);
                CopyFromEventExportCoursesTextParameter(map, settings);
                CopyFromEventExportCoursesStatisticsParameter(map, settings);
            }

            CopyFromModelDataSets(map, settings);
            CopyFromModelDatabaseObjects(map, settings);
            CopyFromModelOimFiles(map, settings);
            CopyFromModelTemplates(map, settings);
            CopyFromModelColours(map, settings);
            CopyFromModelSpotColours(map, settings);
            CopyFromModelFileInfos(map, settings);
            CopyFromModelZooms(map, settings);
            CopyFromModelImportLayers(map, settings);
            CopyFromModelOimFinds(map, settings);
            CopyFromModelSymbolTrees(map, settings);

            CopyFromModelDisplayParameter(map, settings);
            CopyFromModelOimParameter(map, settings);
            CopyFromModelPrintParameter(map, settings);
            CopyFromModelTemplateParameter(map, settings);
            CopyFromModelEpsParameter(map, settings);
            CopyFromModelViewParameter(map, settings);
            CopyFromModelTiffParameter(map, settings);
            CopyFromModelTilesParameter(map, settings);
            CopyFromModelDatabaseParameter(map, settings);
            CopyFromModelExportParameter(map, settings);
            CopyFromModelScaleParameter(map, settings);
            CopyFromModelDatabaseCreateObjectParameter(map, settings);
            CopyFromModelSelectedSpotColoursParameter(map, settings);
            CopyFromModelXmlScriptParameter(map, settings);
            CopyFromModelMiscellaneousSettings(map, settings);

            return settings;
        }
    }
}
