﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace Ocad.IO.Ocad9
{
    internal static class HeaderExtension
    {
        public static Model.Colour GetOrCreateColour(this Model.Header header, Int16 colourNumber, Boolean moveToEnd = false)
        {
            Model.Colour colour = null;
            foreach (Model.Colour s in header.Colours)
            {
                if (s.Number.Equals(colourNumber))
                {
                    if (!moveToEnd)
                    {
                        return s;
                    }
                    colour = s;
                    break;
                }
            }

            if ((colour != null) && (moveToEnd))
            {
                header.Colours.Remove(colour);
                header.Colours.Add(colour);
                return colour;
            }

            colour = new Model.Colour()
            {
                Number = colourNumber
            };
            header.Colours.Add(colour);
            return colour;
        }

        public static Model.SpotColour GetOrCreateSpotColour(this Model.Header header, String spotColourName, Boolean moveToEnd = false)
        {
            Model.SpotColour spotColour = null;
            foreach (Model.SpotColour s in header.SpotColours)
            {
                if (s.Name.Equals(spotColourName))
                {
                    if (!moveToEnd)
                    {
                        return s;
                    }
                    spotColour = s;
                    break;
                }
            }

            if ((spotColour != null) && (moveToEnd))
            {
                header.SpotColours.Remove(spotColour);
                header.SpotColours.Add(spotColour);
                return spotColour;
            }

            spotColour = new Model.SpotColour()
            {
                Name = spotColourName
            };
            header.SpotColours.Add(spotColour);
            return spotColour;
        }

        public static Model.AbstractSymbol GetOrCreateSymbol(this Model.Header header, String symbolNumber, Model.Type.FeatureType objectType)
        {
            foreach (Model.AbstractSymbol s in header.Symbols)
            {
                if (s.Number.Equals(symbolNumber))
                {
                    return s;
                }
            }

            // Should not really happen
            Model.AbstractSymbol symbol;
            switch (objectType)
            {
                case Model.Type.FeatureType.Area:
                    symbol = new Model.AreaSymbol();
                    break;
                case Model.Type.FeatureType.FormattedText:
                case Model.Type.FeatureType.UnformattedText:
                    symbol = new Model.BlockTextSymbol();
                    break;
                case Model.Type.FeatureType.LineText:
                    symbol = new Model.LineTextSymbol();
                    break;
                case Model.Type.FeatureType.Point:
                    symbol = new Model.PointSymbol();
                    break;
                case Model.Type.FeatureType.Rectangle:
                    symbol = new Model.RectangleSymbol();
                    break;
                case Model.Type.FeatureType.Line:
                    symbol = new Model.LineSymbol();
                    break;
                default:
                    return null; // throw
            }
            symbol.Number = symbolNumber;
            header.Symbols.Add(symbol);

            return symbol;
        }

        public static Model.AbstractSymbol GetOrCreateSymbol(this Model.Header header, String symbolNumber, Model.Type.SymbolType symbolType, Boolean moveToEnd = false)
        {
            Model.AbstractSymbol symbol = null;
            foreach (Model.AbstractSymbol s in header.Symbols)
            {
                if (s.Number.Equals(symbolNumber))
                {
                    if (!moveToEnd)
                    {
                        return s;
                    }
                    symbol = s;
                    break;
                }
            }

            if ((symbol != null) && (moveToEnd))
            {
                header.Symbols.Remove(symbol);
                header.Symbols.Add(symbol);
                return symbol;
            }

            switch (symbolType)
            {
                case Model.Type.SymbolType.Area:
                    symbol = new Model.AreaSymbol();
                    break;
                case Model.Type.SymbolType.BlockText:
                    symbol = new Model.BlockTextSymbol();
                    break;
                case Model.Type.SymbolType.LineText:
                    symbol = new Model.LineTextSymbol();
                    break;
                case Model.Type.SymbolType.Point:
                    symbol = new Model.PointSymbol();
                    break;
                case Model.Type.SymbolType.Rectangle:
                    symbol = new Model.RectangleSymbol();
                    break;
                case Model.Type.SymbolType.Line:
                    symbol = new Model.LineSymbol();
                    break;
                default:
                    return null; // throw
            }
            symbol.Number = symbolNumber;
            header.Symbols.Add(symbol);

            return symbol;
        }

        public static Model.SymbolTree GetOrCreateSymbolTree(this Model.Header header, Int16 groupId, Boolean moveToEnd = false)
        {
            if (groupId == 0)
            {
                return null;
            }

            Model.SymbolTree symbolTree = null;
            foreach (Model.SymbolTree s in header.SymbolTrees)
            {
                if (s.GroupId.Equals(groupId))
                {
                    if (!moveToEnd)
                    {
                        return s;
                    }
                    symbolTree = s;
                    break;
                }
            }

            if ((symbolTree != null) && (moveToEnd))
            {
                header.SymbolTrees.Remove(symbolTree);
                header.SymbolTrees.Add(symbolTree);
                return symbolTree;
            }

            symbolTree = new Model.SymbolTree()
            {
                GroupId = groupId
            };
            header.SymbolTrees.Add(symbolTree);
            return symbolTree;
        }

        public static Model.ImportLayer GetOrCreateImportLayer(this Model.Header header, Int16 layerNumber, Boolean moveToEnd = false)
        {
            if (layerNumber == 0)
            {
                return null;
            }

            Model.ImportLayer importLayer = null;
            foreach (Model.ImportLayer s in header.ImportLayers)
            {
                if (s.LayerNumber.Equals(layerNumber))
                {
                    if (!moveToEnd)
                    {
                        return s;
                    }
                    importLayer = s;
                    break;
                }
            }

            if ((importLayer != null) && (moveToEnd))
            {
                header.ImportLayers.Remove(importLayer);
                header.ImportLayers.Add(importLayer);
                return importLayer;
            }

            importLayer = new Model.ImportLayer()
            {
                LayerNumber = layerNumber
            };
            header.ImportLayers.Add(importLayer);
            return importLayer;
        }
    }
}
