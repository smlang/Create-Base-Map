﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Ocad.IO.Ocad9
{
    internal static class Constant
    {
        internal const Int16 OCAD_MARK = 3245;
        internal const Int32 MAX_HEADERS = 256;

        internal const Int32 DATA_SIZE = 8;
    }
}
