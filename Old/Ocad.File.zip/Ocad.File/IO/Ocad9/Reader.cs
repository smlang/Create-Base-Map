﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace Ocad.IO.Ocad9
{
    public class Reader : BinaryReader
    {
        internal Model.Header ModelHeader { get; set; }

        public Reader(Stream stream)
            : base(stream, Encoding.Unicode)
        {
        }

        #region Read Methods
        public Model.Header ReadContent()
        {
            BaseStream.Seek(0, SeekOrigin.Begin);

            Int16 ocadMark = ReadInt16();
            if (Constant.OCAD_MARK != ocadMark)
            {
                return null;
            }

            Model.Type.FileType fileType = (Model.Type.FileType)ReadByte();
            ReadByte(); // fileStatus
            Int16 version = ReadInt16();
            Int16 subversion = ReadInt16();
            Int32 symbolHeaderBlockPointer = ReadInt32();
            Int32 objectHeaderBlockPointer = ReadInt32();
            ReadInt32(); // reserved0
            ReadInt32(); // reserved1
            ReadInt32(); // reserved2
            ReadInt32(); // infoSize
            Int32 settingHeaderBlockPointer = ReadInt32();
            Int32 fileNamePointer = ReadInt32();
            Int32 fileNameSize = ReadInt32();
            ReadInt32(); // reserved4

            ModelHeader = new Model.Header();
            ModelHeader.FileType = new Model.FileType()
            {
                Value = fileType
            };
            ModelHeader.FileVersion = new Model.FileVersion()
            {
                Version = version,
                Subversion = subversion
            };

            // Read Settings (inc Colours) before Symbols where they will be referenced
            ReadBlocks<Record.Setting>(settingHeaderBlockPointer);

            // Read Symbols before Objects where they will be referenced
            ReadBlocks<Record.Symbol>(symbolHeaderBlockPointer);

            ReadBlocks<Record.Object>(objectHeaderBlockPointer);

            String text = ReadAsciiString(fileNamePointer);
            ModelHeader.FileName = new Model.FileName()
            {
                Value = text
            };

            return ModelHeader;
        }

        internal Boolean ReadWordBoolean()
        {
            this.BaseStream.Seek(1, SeekOrigin.Current);
            return ReadBoolean();
        }

        internal String ReadEncodedString()
        {
            StringBuilder b = new StringBuilder();
            while (true)
            {
                char c = this.ReadChar();
                if (c == '\0')
                {
                    return b.ToString();
                }
                b.Append(c);
            }
        }

        internal String ReadAsciiString(Int32 stringPointer)
        {
            this.BaseStream.Seek(stringPointer, SeekOrigin.Begin);

            StringBuilder b = new StringBuilder();
            while (true)
            {
                char c = (char)this.ReadByte();
                if (c == '\0')
                {
                    return b.ToString();
                }
                b.Append(c);
            }
        }

        internal String ReadPascalString(Byte stringMaxSize)
        {
            Byte stringLength = ReadByte();
            if (stringLength > stringMaxSize)
            {
                stringLength = stringMaxSize;
            }

            String result = Encoding.ASCII.GetString(this.ReadBytes(stringLength));
            if (stringMaxSize > stringLength)
            {
                this.BaseStream.Seek(stringMaxSize - stringLength, SeekOrigin.Current);
            }

            return result;
        }

        internal Model.Point ReadPoint(out Type.PointFlag internalPointFlag)
        {
            Model.Point point = new Model.Point();

            Int32 x32 = ReadInt32();
            point.MainXMm = (x32 >> 8) / 100.0;

            Int32 y32 = ReadInt32();
            point.MainYMm = (y32 >> 8) / 100.0;

            internalPointFlag = (Type.PointFlag)((x32 & 255) + ((y32 & 255) << 8));
            point.MainPointFlag = (Model.Type.PointFlag)internalPointFlag;

            return point;
        }

        internal List<Model.Point> ReadPoints(Int32 nPoints)
        {
            List<Model.Point> mergePoints = new List<Model.Point>();
            Model.Point secondBezierPoint = null;
            Model.Point mainPoint = null;
            for (int i = 0; i < nPoints; i++)
            {
                Type.PointFlag internalPointFlag;
                Model.Point p = ReadPoint(out internalPointFlag);
                if (internalPointFlag == Type.PointFlag.SecondBezierPoint)
                {
                    secondBezierPoint = p;
                }
                else if (internalPointFlag == Type.PointFlag.FirstBezierPoint)
                {
                    mainPoint.FirstBezierXMm = p.MainXMm;
                    mainPoint.FirstBezierYMm = p.MainYMm;
                    mainPoint.FirstBezierUse = true;
                }
                else
                {
                    mainPoint = p;
                    mergePoints.Add(mainPoint);
                    if (secondBezierPoint != null)
                    {
                        mainPoint.SecondBezierXMm = secondBezierPoint.MainXMm;
                        mainPoint.SecondBezierYMm = secondBezierPoint.MainYMm;
                        mainPoint.SecondBezierUse = true;
                        secondBezierPoint = null;
                    }
                }
            }

            return mergePoints;
        }

        internal Model.Shape ReadShape()
        {
            Model.Shape shape = new Model.Shape();

            shape.Type = (Model.Type.ShapeType)ReadInt16();
            shape.Style = (Model.Type.LineStyle)ReadUInt16();
            shape.Colour = ModelHeader.GetOrCreateColour(ReadInt16());
            shape.LineWidthMm = ReadInt16() / 100.0;
            shape.DiameterMm = ReadInt16() / 100.0;
            Int16 nPoints = ReadInt16();
            Int16 reserved0 = ReadInt16();
            Int16 reserved1 = ReadInt16();
            shape.Points = ReadPoints(nPoints);

            return shape;
        }

        internal List<Model.Shape> ReadShapes(Int32 shapesDataSize)
        {
            List<Model.Shape> shapes = new List<Model.Shape>();
            long offsetLimit = this.BaseStream.Position + (shapesDataSize * 8);
            while (this.BaseStream.Position < offsetLimit)
            {
                shapes.Add(ReadShape());
            }
            return shapes;
        }

        private void ReadBlocks<R>(Int32 recordPointer) where R : Record.AbstractRecord, new()
        {
            while (recordPointer != 0)
            {
                Int32 nextRecordPointer;
                ReadBlock<R>(recordPointer, out nextRecordPointer);
                recordPointer = nextRecordPointer;
            }
        }

        private void ReadBlock<R>(Int32 recordPointer, out Int32 nextRecordPointer) where R : Record.AbstractRecord, new()
        {
            this.BaseStream.Seek(recordPointer, SeekOrigin.Begin);

            nextRecordPointer = this.ReadInt32();
            List<R> records = new List<R>();
            // Read all headers, before reading any body
            for (int i = 0; i < Constant.MAX_HEADERS; i++)
            {
                R header = new R();
                header.ReadHeader(this);
                if (header.BodyPointer != 0)
                {
                    records.Add(header);
                }
            }
            // Can now read bodies
            foreach (R header in records)
            {
                header.ReadBody(this);
            }
        }

        internal protected static String ConvertToSymbolNumber(Int32 symbolNumberInteger)
        {
            return String.Format("{0}.{1}", (symbolNumberInteger / 1000), (symbolNumberInteger % 1000));
        }
        #endregion
    }
}
