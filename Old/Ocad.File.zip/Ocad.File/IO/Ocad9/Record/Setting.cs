﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;

namespace Ocad.IO.Ocad9.Record
{
    internal class Setting : AbstractRecord
    {
        private Helper.Setting setting;

        internal override void ReadHeader(Reader reader)
        {
            setting = new Helper.Setting();

            BodyPointer = reader.ReadInt32();
            reader.ReadInt32(); // bodyDataSize
            setting.SettingType = (Type.SettingType)reader.ReadInt32();
            setting.Index = reader.ReadInt32();
        }

        internal override void ReadBody(Reader reader)
        {
            setting.ConcatenatedValues = reader.ReadAsciiString(BodyPointer);
            setting.CopyToModel(reader);
        }

        internal override Int32 SizeBody(Writer writer, Int32 offset, object o)
        {
            setting = (Helper.Setting)o;
            BodyPointer = offset;
            BodyByteSize = writer.SizeAsciiString(setting.ConcatenatedValues);
            return BodyPointer + BodyByteSize;
        }

        internal override void WriteHeader(Writer writer)
        {
            writer.Write(BodyPointer);
            writer.Write(BodyByteSize);
            writer.Write((Int32)setting.SettingType);
            writer.Write(Writer.INT32_BLANK);
        }

        internal override void WriteBody(Writer writer)
        {
            writer.WriteAsciiString(setting.ConcatenatedValues);
        }
    }
}
