﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;

namespace Ocad.IO.Ocad9.Record.Helper
{
    internal partial class Setting
    {
        private const String TEMPLATE_PARAMETER_DEFAULT_SCALE = "s";

        private void CopyToModelTemplateParameter(Model.Header header)
        {
            Model.TemplateParameter setting = new Model.TemplateParameter();
            header.TemplateParameter = setting;

            int i = 0;
            while (i <= this.codeValue.GetUpperBound(0))
            {
                string code = this.codeValue[i, 0];
                switch (code)
                {
                    case TEMPLATE_PARAMETER_DEFAULT_SCALE:
                        setting.DefaultScale = Int32.Parse(this.codeValue[i, 1]);
                        break;
                }
                i++;
            }
        }

        private static void CopyFromModelTemplateParameter(Model.Header header, List<Setting> settings)
        {
            Model.TemplateParameter source = header.TemplateParameter;
            if (source != null)
            {
                Setting setting = new Setting();
                setting.SettingType = Type.SettingType.TemplateParameter;
                settings.Add(setting);

                StringBuilder b = new StringBuilder();
                b.AppendFormat("{0}{1}{2}", DELIMITATOR, TEMPLATE_PARAMETER_DEFAULT_SCALE, source.DefaultScale);

                setting.ConcatenatedValues = b.ToString();
            }
        }
    }
}
