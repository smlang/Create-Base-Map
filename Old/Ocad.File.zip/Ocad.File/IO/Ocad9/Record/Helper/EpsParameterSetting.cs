﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;

namespace Ocad.IO.Ocad9.Record.Helper
{
    internal partial class Setting
    {
        private const String EPS_PARAMETER_RESOLUTION = "r";

        private void CopyToModelEpsParameter(Model.Header header)
        {
            Model.EpsParameter setting = new Model.EpsParameter();
            header.EpsParameter = setting;

            int i = 0;
            while (i <= this.codeValue.GetUpperBound(0))
            {
                string code = this.codeValue[i, 0];
                switch (code)
                {
                    case EPS_PARAMETER_RESOLUTION:
                        setting.Resolution = Double.Parse(this.codeValue[i, 1]);
                        break;
                }
                i++;
            }
        }

        private static void CopyFromModelEpsParameter(Model.Header header, List<Setting> settings)
        {
            Model.EpsParameter source = header.EpsParameter;
            if (source != null)
            {
                Setting setting = new Setting();
                setting.SettingType = Type.SettingType.EpsParameter;
                settings.Add(setting);

                StringBuilder b = new StringBuilder();
                b.AppendFormat("{0}{1}{2:0.0#}", DELIMITATOR, EPS_PARAMETER_RESOLUTION, source.Resolution);

                setting.ConcatenatedValues = b.ToString();
            }
        }
    }
}
