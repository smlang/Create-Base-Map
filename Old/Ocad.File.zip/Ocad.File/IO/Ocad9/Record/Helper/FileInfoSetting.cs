﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;

namespace Ocad.IO.Ocad9.Record.Helper
{
    internal partial class Setting
    {
        private void CopyToModelFileInfo(Model.Header header)
        {
            Model.FileInfo setting = new Model.FileInfo();
            header.FileInfos.Add(setting);

            setting.Value = this.mainValue;
        }

        private static void CopyFromModelFileInfos(Model.Header header, List<Setting> settings)
        {
            foreach (Model.FileInfo source in header.FileInfos)
            {
                Setting setting = new Setting();
                setting.SettingType = Type.SettingType.FileInfo;
                settings.Add(setting);

                setting.ConcatenatedValues = source.Value;
            }
        }
    }
}
