﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;

namespace Ocad.IO.Ocad9.Record.Helper
{
    internal partial class Setting
    {
        private const String SYMBOL_TREE_GROUP_ID = "g";
        private const String SYMBOL_TREE_FIRST_NODE_IN_SUBGROUP = "f";
        private const String SYMBOL_TREE_LAST_NODE_IN_SUBGROUP = "l";
        private const String SYMBOL_TREE_DEPTH = "i";
        private const String SYMBOL_TREE_EXPAND = "e";

        private Model.SymbolTree CopyToModelSymbolTree(Model.Header header)
        {
            Int16 groupId = 0;
            int i = 0;
            int groupIdIndex = -1;
            while ((i <= this.codeValue.GetUpperBound(0)) && (groupIdIndex < 0))
            {
                string code = this.codeValue[i, 0];
                switch (code)
                {
                    case SYMBOL_TREE_GROUP_ID:
                        groupId = Int16.Parse(this.codeValue[i, 1]);
                        groupIdIndex = i;
                        break;
                }
                i++;
            }

            Model.SymbolTree setting = header.GetOrCreateSymbolTree(groupId, true);

            setting.Name = this.mainValue;

            while (i <= this.codeValue.GetUpperBound(0))
            {
                string code = this.codeValue[i, 0];
                switch (code)
                {
                    case SYMBOL_TREE_EXPAND:
                        setting.Expand = this.codeValue[i, 1].Equals(TRUE);
                        break;
                    case SYMBOL_TREE_FIRST_NODE_IN_SUBGROUP:
                        setting.FirstNodeInSubgroup = this.codeValue[i, 1].Equals(TRUE);
                        break;
                    case SYMBOL_TREE_LAST_NODE_IN_SUBGROUP:
                        setting.LastNodeInSubgroup = this.codeValue[i, 1].Equals(TRUE);
                        break;
                    case SYMBOL_TREE_DEPTH:
                        setting.Depth = Byte.Parse(this.codeValue[i, 1]);
                        break;
                }
                i++;
            }

            return setting;
        }

        private static void CopyFromModelSymbolTrees(Model.Header header, List<Setting> settings)
        {
            foreach (Model.SymbolTree source in header.SymbolTrees)
            {
                Setting setting = new Setting();
                setting.SettingType = Type.SettingType.SymbolTree;
                settings.Add(setting);

                StringBuilder b = new StringBuilder(source.Name);
                b.AppendFormat("{0}{1}{2}", DELIMITATOR, SYMBOL_TREE_GROUP_ID, source.GroupId);
                b.AppendFormat("{0}{1}{2}", DELIMITATOR, SYMBOL_TREE_EXPAND, source.Expand ? TRUE : FALSE);
                b.AppendFormat("{0}{1}{2}", DELIMITATOR, SYMBOL_TREE_FIRST_NODE_IN_SUBGROUP, source.FirstNodeInSubgroup ? TRUE : FALSE);
                b.AppendFormat("{0}{1}{2}", DELIMITATOR, SYMBOL_TREE_LAST_NODE_IN_SUBGROUP, source.LastNodeInSubgroup ? TRUE : FALSE);
                b.AppendFormat("{0}{1}{2}", DELIMITATOR, SYMBOL_TREE_DEPTH, source.Depth);
                setting.ConcatenatedValues = b.ToString();
            }
        }
    }
}
