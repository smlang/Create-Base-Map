﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;

namespace Ocad.IO.Ocad9.Record.Helper
{
    internal partial class Setting
    {
        private const String VIEW_PARAMETER_DRAFT_MODE_IGN_FOR_OCAD_MAP = "b";
        private const String VIEW_PARAMETER_DRAFT_MODE_IGN_FOR_BACKGROUND_MAPS = "c";
        private const String VIEW_PARAMETER_HIDE_BACKGROUND_MAPS = "d";
        private const String VIEW_PARAMETER_DRAFT_MODE_FOR_OCAD_MAP = "m";
        private const String VIEW_PARAMETER_DRAFT_MODE_FOR_BACKGROUND_MAPS = "t";
        private const String VIEW_PARAMETER_VIEW_MODE = "v";
        private const String VIEW_PARAMETER_OFFSET_CENTRE_X_MM = "x";
        private const String VIEW_PARAMETER_OFFSET_CENTRE_Y_MM = "y";
        private const String VIEW_PARAMETER_HATCHED = "h";
        private const String VIEW_PARAMETER_ZOOM = "z";

        private void CopyToModelViewParameter(Model.Header header)
        {
            Model.ViewParameter setting = new Model.ViewParameter();
            header.ViewParameter = setting;

            int i = 0;
            while (i <= this.codeValue.GetUpperBound(0))
            {
                string code = this.codeValue[i, 0];
                switch (code)
                {
                    case VIEW_PARAMETER_DRAFT_MODE_IGN_FOR_OCAD_MAP:
                        setting.DraftModeIgnForOcadMap = Byte.Parse(this.codeValue[i, 1]);
                        break;
                    case VIEW_PARAMETER_DRAFT_MODE_IGN_FOR_BACKGROUND_MAPS:
                        setting.DraftModeIgnForBackgroundMaps = Byte.Parse(this.codeValue[i, 1]);
                        break;
                    case VIEW_PARAMETER_HIDE_BACKGROUND_MAPS:
                        setting.HideBackgroundMaps = this.codeValue[i, 1].Equals(TRUE);
                        break;
                    case VIEW_PARAMETER_DRAFT_MODE_FOR_OCAD_MAP:
                        setting.DraftModeForOcadMap = Byte.Parse(this.codeValue[i, 1]);
                        break;
                    case VIEW_PARAMETER_DRAFT_MODE_FOR_BACKGROUND_MAPS:
                        setting.DraftModeForBackgroundMaps = Byte.Parse(this.codeValue[i, 1]);
                        break;
                    case VIEW_PARAMETER_VIEW_MODE:
                        setting.ViewMode = Byte.Parse(this.codeValue[i, 1]);
                        break;
                    case VIEW_PARAMETER_OFFSET_CENTRE_X_MM:
                        setting.OffsetCentreXMm = Double.Parse(this.codeValue[i, 1]);
                        break;
                    case VIEW_PARAMETER_OFFSET_CENTRE_Y_MM:
                        setting.OffsetCentreYMm = Double.Parse(this.codeValue[i, 1]);
                        break;
                    case VIEW_PARAMETER_HATCHED:
                        setting.Hatched = this.codeValue[i, 1].Equals(TRUE);
                        break;
                    case VIEW_PARAMETER_ZOOM:
                        setting.Zoom = Double.Parse(this.codeValue[i, 1]);
                        break;
                }
                i++;
            }
        }

        private static void CopyFromModelViewParameter(Model.Header header, List<Setting> settings)
        {
            Model.ViewParameter source = header.ViewParameter;
            if (source != null)
            {
                Setting setting = new Setting();
                setting.SettingType = Type.SettingType.ViewParameter;
                settings.Add(setting);

                StringBuilder b = new StringBuilder();
                b.AppendFormat("{0}{1}{2:0.000000}", DELIMITATOR, VIEW_PARAMETER_OFFSET_CENTRE_X_MM, source.OffsetCentreXMm);
                b.AppendFormat("{0}{1}{2:0.000000}", DELIMITATOR, VIEW_PARAMETER_OFFSET_CENTRE_Y_MM, source.OffsetCentreYMm);
                b.AppendFormat("{0}{1}{2:0.000000}", DELIMITATOR, VIEW_PARAMETER_ZOOM, source.Zoom);
                b.AppendFormat("{0}{1}{2}", DELIMITATOR, VIEW_PARAMETER_VIEW_MODE, source.ViewMode);
                b.AppendFormat("{0}{1}{2}", DELIMITATOR, VIEW_PARAMETER_DRAFT_MODE_FOR_OCAD_MAP, source.DraftModeForOcadMap);
                b.AppendFormat("{0}{1}{2}", DELIMITATOR, VIEW_PARAMETER_DRAFT_MODE_FOR_BACKGROUND_MAPS, source.DraftModeForBackgroundMaps);
                b.AppendFormat("{0}{1}{2}", DELIMITATOR, VIEW_PARAMETER_DRAFT_MODE_IGN_FOR_OCAD_MAP, source.DraftModeIgnForOcadMap);
                b.AppendFormat("{0}{1}{2}", DELIMITATOR, VIEW_PARAMETER_DRAFT_MODE_IGN_FOR_BACKGROUND_MAPS, source.DraftModeIgnForBackgroundMaps);
                b.AppendFormat("{0}{1}{2}", DELIMITATOR, VIEW_PARAMETER_HATCHED, source.Hatched ? TRUE : FALSE);
                b.AppendFormat("{0}{1}{2}", DELIMITATOR, VIEW_PARAMETER_HIDE_BACKGROUND_MAPS, source.HideBackgroundMaps ? TRUE : FALSE);

                setting.ConcatenatedValues = b.ToString();
            }
        }
    }
}
