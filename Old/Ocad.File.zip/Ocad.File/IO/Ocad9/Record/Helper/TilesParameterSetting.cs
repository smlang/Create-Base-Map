﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;

namespace Ocad.IO.Ocad9.Record.Helper
{
    internal partial class Setting
    {
        private const String TILES_PARAMETER_WIDTH = "w";
        private const String TILES_PARAMETER_HEIGHT = "h";

        private void CopyToModelTilesParameter(Model.Header header)
        {
            Model.TilesParameter setting = new Model.TilesParameter();
            header.TilesParameter = setting;

            int i = 0;
            while (i <= this.codeValue.GetUpperBound(0))
            {
                string code = this.codeValue[i, 0];
                switch (code)
                {
                    case TILES_PARAMETER_WIDTH:
                        setting.Width = Int32.Parse(this.codeValue[i, 1]);
                        break;
                    case TILES_PARAMETER_HEIGHT:
                        setting.Height = Int32.Parse(this.codeValue[i, 1]);
                        break;
                }
                i++;
            }
        }

        private static void CopyFromModelTilesParameter(Model.Header header, List<Setting> settings)
        {
            Model.TilesParameter source = header.TilesParameter;
            if (source != null)
            {
                Setting setting = new Setting();
                setting.SettingType = Type.SettingType.TilesParameter;
                settings.Add(setting);

                StringBuilder b = new StringBuilder();
                b.AppendFormat("{0}{1}{2}", DELIMITATOR, TILES_PARAMETER_WIDTH, source.Width);
                b.AppendFormat("{0}{1}{2}", DELIMITATOR, TILES_PARAMETER_HEIGHT, source.Height);

                setting.ConcatenatedValues = b.ToString();
            }
        }
    }
}
