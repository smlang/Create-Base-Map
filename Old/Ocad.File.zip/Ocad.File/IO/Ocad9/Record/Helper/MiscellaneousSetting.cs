﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;

namespace Ocad.IO.Ocad9.Record.Helper
{
    internal partial class Setting
    {
        private void CopyToModelMiscellaneous(Model.Header header)
        {
            Model.Miscellaneous setting = new Model.Miscellaneous()
            {
                TypeId = (Int32)SettingType,
                MainValue = mainValue,
                CodeValue = codeValue
            };
            header.MiscellaneousSettings.Add(setting);
        }

        private static void CopyFromModelMiscellaneousSettings(Model.Header header, List<Setting> settings)
        {
            foreach (Model.Miscellaneous source in header.MiscellaneousSettings)
            {
                Setting setting = new Setting();
                setting.SettingType = (Type.SettingType)source.TypeId;
                settings.Add(setting);

                StringBuilder b = new StringBuilder(source.MainValue);
                for (int i = 0; i < source.CodeValue.GetUpperBound(0); i++)
                {
                    b.AppendFormat("{0}{1}{2}", DELIMITATOR, source.CodeValue[i, 0], source.CodeValue[i, 1]);
                }
                setting.ConcatenatedValues = b.ToString(); ;
            }
        }
    }
}
