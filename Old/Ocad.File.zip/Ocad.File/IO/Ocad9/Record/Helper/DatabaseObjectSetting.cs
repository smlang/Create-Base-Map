﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;

namespace Ocad.IO.Ocad9.Record.Helper
{
    internal partial class Setting
    {
        private const String DATABASE_OBJECT_DATA_SET = "d";

        private void CopyToModelDatabaseObject(Model.Header header)
        {
            Model.DatabaseObject setting = new Model.DatabaseObject();
            header.DatabaseObjects.Add(setting);

            int i = 0;
            while (i <= this.codeValue.GetUpperBound(0))
            {
                string code = this.codeValue[i, 0];
                switch (code)
                {
                    case DATABASE_OBJECT_DATA_SET:
                        setting.DataSet = this.codeValue[i, 1];
                        break;
                }
                i++;
            }
        }

        private static void CopyFromModelDatabaseObjects(Model.Header header, List<Setting> settings)
        {
            foreach (Model.DatabaseObject source in header.DatabaseObjects)
            {
                Setting setting = new Setting();
                setting.SettingType = Type.SettingType.DatabaseObject;
                settings.Add(setting);

                StringBuilder b = new StringBuilder();
                if (source.DataSet != null)
                {
                    b.AppendFormat("{0}{1}{2}", DELIMITATOR, DATABASE_OBJECT_DATA_SET, source.DataSet);
                }


                setting.ConcatenatedValues = b.ToString();
            }
        }
    }
}
