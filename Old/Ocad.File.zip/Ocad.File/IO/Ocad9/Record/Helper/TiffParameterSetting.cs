﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;

namespace Ocad.IO.Ocad9.Record.Helper
{
    internal partial class Setting
    {
        private const String TIFF_PARAMETER_COMPRESSION = "c";
        private const String TIFF_PARAMETER_GEOTIFF = "g";
        private const String TIFF_PARAMETER_PIXEL_SIZE = "s";
        private const String TIFF_PARAMETER_TFW_FILE = "w";

        private void CopyToModelTiffParameter(Model.Header header)
        {
            Model.TiffParameter setting = new Model.TiffParameter();
            header.TiffParameter = setting;

            int i = 0;
            while (i <= this.codeValue.GetUpperBound(0))
            {
                string code = this.codeValue[i, 0];
                switch (code)
                {
                    case TIFF_PARAMETER_COMPRESSION:
                        setting.Compression = (Model.Type.TiffCompression)Byte.Parse(this.codeValue[i, 1]);
                        break;
                    case TIFF_PARAMETER_GEOTIFF:
                        setting.GeoTiff = this.codeValue[i, 1].Equals(TRUE);
                        break;
                    case TIFF_PARAMETER_PIXEL_SIZE:
                        setting.PixelSize = Double.Parse(this.codeValue[i, 1]);
                        break;
                    case TIFF_PARAMETER_TFW_FILE:
                        setting.TfwFile = this.codeValue[i, 1].Equals(TRUE);
                        break;
                }
                i++;
            }
        }

        private static void CopyFromModelTiffParameter(Model.Header header, List<Setting> settings)
        {
            Model.TiffParameter source = header.TiffParameter;
            if (source != null)
            {
                Setting setting = new Setting();
                setting.SettingType = Type.SettingType.TiffParameter;
                settings.Add(setting);

                StringBuilder b = new StringBuilder();
                if (source.PixelSize.HasValue)
                {
                    b.AppendFormat("{0}{1}{2:0.00}", DELIMITATOR, TIFF_PARAMETER_PIXEL_SIZE, source.PixelSize.Value);
                }
                if (source.GeoTiff.HasValue)
                {
                    b.AppendFormat("{0}{1}{2}", DELIMITATOR, TIFF_PARAMETER_GEOTIFF, source.GeoTiff.Value ? TRUE : FALSE);
                }
                if (source.Compression.HasValue)
                {
                    b.AppendFormat("{0}{1}{2}", DELIMITATOR, TIFF_PARAMETER_COMPRESSION, (Byte)source.Compression.Value);
                }
                if (source.TfwFile.HasValue)
                {
                    b.AppendFormat("{0}{1}{2}", DELIMITATOR, TIFF_PARAMETER_TFW_FILE, source.TfwFile.Value ? TRUE : FALSE);
                }

                setting.ConcatenatedValues = b.ToString();
            }
        }
    }
}
