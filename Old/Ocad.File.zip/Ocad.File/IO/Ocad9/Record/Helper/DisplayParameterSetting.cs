﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;

namespace Ocad.IO.Ocad9.Record.Helper
{
    internal partial class Setting
    {
        private const String DISPLAY_PARAMETER_SHOW_SYMBOL_FAVOURITIES = "f";
        private const String DISPLAY_PARAMETER_SELECTED_SYMBOL_TREE = "g";
        private const String DISPLAY_PARAMETER_SELECTED_SYMBOL = "s";
        private const String DISPLAY_PARAMETER_SHOW_SYMBOL_TREE = "t";
        private const String DISPLAY_PARAMETER_SYMBOL_BOX_WIDTH_PIXEL = "x";
        private const String DISPLAY_PARAMETER_SYMBOL_BOX_HEIGHT_PIXEL = "y";
        private const String DISPLAY_PARAMETER_HORIZONTAL_SPLITTED_PIXELS_FROM_TOP = "h";
        private const String DISPLAY_PARAMETER_VERTICAL_SPLITTED_PIXELS_FROM_TOP = "v";

        private void CopyToModelDisplayParameter(Model.Header header)
        {
            Model.DisplayParameter setting = new Model.DisplayParameter();
            header.DisplayParameter = setting;

            int i = 0;
            while (i <= this.codeValue.GetUpperBound(0))
            {
                string code = this.codeValue[i, 0];
                switch (code)
                {
                    case DISPLAY_PARAMETER_SHOW_SYMBOL_FAVOURITIES:
                        setting.ShowSymbolFavourities = this.codeValue[i, 1].Equals(TRUE);
                        break;
                    case DISPLAY_PARAMETER_SELECTED_SYMBOL_TREE:
                        Int16 symbolTreeGroupId = Int16.Parse(this.codeValue[i, 1]);
                        setting.SelectedSymbolTree = header.GetOrCreateSymbolTree(symbolTreeGroupId);
                        break;
                    case DISPLAY_PARAMETER_SELECTED_SYMBOL:
                        setting.SelectedSymbol = Int16.Parse(this.codeValue[i, 1]);
                        break;
                    case DISPLAY_PARAMETER_SHOW_SYMBOL_TREE:
                        setting.ShowSymbolTree = this.codeValue[i, 1].Equals(TRUE);
                        break;
                    case DISPLAY_PARAMETER_SYMBOL_BOX_WIDTH_PIXEL:
                        setting.SymbolBoxWidthPixel = Int16.Parse(this.codeValue[i, 1]);
                        break;
                    case DISPLAY_PARAMETER_SYMBOL_BOX_HEIGHT_PIXEL:
                        setting.SymbolBoxHeightPixel = Int16.Parse(this.codeValue[i, 1]);
                        break;
                    case DISPLAY_PARAMETER_HORIZONTAL_SPLITTED_PIXELS_FROM_TOP:
                        setting.HorizontalSplittedPixelsFromTop = Int16.Parse(this.codeValue[i, 1]);
                        break;
                    case DISPLAY_PARAMETER_VERTICAL_SPLITTED_PIXELS_FROM_TOP:
                        setting.VerticalSplittedPixelsFromRight = Int16.Parse(this.codeValue[i, 1]);
                        break;
                }
                i++;
            }
        }

        private static void CopyFromModelDisplayParameter(Model.Header header, List<Setting> settings)
        {
            Model.DisplayParameter source = header.DisplayParameter;
            if (source != null)
            {
                Setting setting = new Setting();
                setting.SettingType = Type.SettingType.DisplayParameter;
                settings.Add(setting);

                StringBuilder b = new StringBuilder();
                if (source.HorizontalSplittedPixelsFromTop.HasValue)
                {
                    b.AppendFormat("{0}{1}{2}", DELIMITATOR, DISPLAY_PARAMETER_HORIZONTAL_SPLITTED_PIXELS_FROM_TOP, source.HorizontalSplittedPixelsFromTop.Value);
                }
                if (source.VerticalSplittedPixelsFromRight.HasValue)
                {
                    b.AppendFormat("{0}{1}{2}", DELIMITATOR, DISPLAY_PARAMETER_VERTICAL_SPLITTED_PIXELS_FROM_TOP, source.VerticalSplittedPixelsFromRight.Value);
                }
                if (source.SelectedSymbol.HasValue)
                {
                    b.AppendFormat("{0}{1}{2}", DELIMITATOR, DISPLAY_PARAMETER_SELECTED_SYMBOL, source.SelectedSymbol.Value);
                }
                if (source.SelectedSymbolTree != null)
                {
                    b.AppendFormat("{0}{1}{2}", DELIMITATOR, DISPLAY_PARAMETER_SELECTED_SYMBOL_TREE, source.SelectedSymbolTree.GroupId);
                }
                if (source.ShowSymbolFavourities.HasValue)
                {
                    b.AppendFormat("{0}{1}{2}", DELIMITATOR, DISPLAY_PARAMETER_SHOW_SYMBOL_FAVOURITIES, source.ShowSymbolFavourities.Value ? TRUE : FALSE);
                }
                if (source.ShowSymbolTree.HasValue)
                {
                    b.AppendFormat("{0}{1}{2}", DELIMITATOR, DISPLAY_PARAMETER_SHOW_SYMBOL_TREE, source.ShowSymbolTree.Value ? TRUE : FALSE);
                }
                if (source.SymbolBoxWidthPixel.HasValue)
                {
                    b.AppendFormat("{0}{1}{2}", DELIMITATOR, DISPLAY_PARAMETER_SYMBOL_BOX_WIDTH_PIXEL, source.SymbolBoxWidthPixel.Value);
                }
                if (source.SymbolBoxHeightPixel.HasValue)
                {
                    b.AppendFormat("{0}{1}{2}", DELIMITATOR, DISPLAY_PARAMETER_SYMBOL_BOX_HEIGHT_PIXEL, source.SymbolBoxHeightPixel.Value);
                }

                setting.ConcatenatedValues = b.ToString();
            }
        }
    }
}
