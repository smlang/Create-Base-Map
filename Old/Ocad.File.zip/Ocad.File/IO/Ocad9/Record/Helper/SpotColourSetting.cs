﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;

namespace Ocad.IO.Ocad9.Record.Helper
{
    internal partial class Setting
    {
        private const String SPOT_COLOUR_NUMBER_CODE = "n";
        private const String SPOT_COLOUR_VISIBLE_CODE = "v";
        private const String SPOT_COLOUR_CYAN_CODE = "c";
        private const String SPOT_COLOUR_MAGENTA_CODE = "m";
        private const String SPOT_COLOUR_YELLOW_CODE = "y";
        private const String SPOT_COLOUR_BLACK_CODE = "k";
        private const String SPOT_COLOUR_FREQUENCY_CODE = "f";
        private const String SPOT_COLOUR_HALFTONE_ANGLE_CODE = "a";

        private void CopyToModelSpotColour(Model.Header header)
        {
            Model.SpotColour setting = header.GetOrCreateSpotColour(this.mainValue, true);
            
            setting.Name = this.mainValue;
            int i = 0;
            while (i <= this.codeValue.GetUpperBound(0))
            {
                string code = this.codeValue[i, 0];
                switch (code)
                {
                    case SPOT_COLOUR_VISIBLE_CODE:
                        setting.Visible = this.codeValue[i, 1].Equals(TRUE);
                        break;
                    case SPOT_COLOUR_NUMBER_CODE:
                        setting.Number = Int16.Parse(this.codeValue[i, 1]);
                        break;
                    case SPOT_COLOUR_FREQUENCY_CODE:
                        setting.FrequencyLpi = Double.Parse(this.codeValue[i, 1]) / 10.0;
                        break;
                    case SPOT_COLOUR_HALFTONE_ANGLE_CODE:
                        setting.HalftoneAngle = Double.Parse(this.codeValue[i, 1]);
                        break;
                    case SPOT_COLOUR_CYAN_CODE:
                        setting.Cyan = Double.Parse(this.codeValue[i, 1]);
                        break;
                    case SPOT_COLOUR_MAGENTA_CODE:
                        setting.Magenta = Double.Parse(this.codeValue[i, 1]);
                        break;
                    case SPOT_COLOUR_YELLOW_CODE:
                        setting.Yellow = Double.Parse(this.codeValue[i, 1]);
                        break;
                    case SPOT_COLOUR_BLACK_CODE:
                        setting.Black = Double.Parse(this.codeValue[i, 1]);
                        break;
                }
                i++;
            }
        }

        private static void CopyFromModelSpotColours(Model.Header header, List<Setting> settings)
        {
            foreach (Model.SpotColour source in header.SpotColours)
            {
                Setting setting = new Setting();
                setting.SettingType = Type.SettingType.SpotColour;
                settings.Add(setting);

                StringBuilder b = new StringBuilder(source.Name);
                b.AppendFormat("{0}{1}{2}", DELIMITATOR, SPOT_COLOUR_NUMBER_CODE, source.Number);
                b.AppendFormat("{0}{1}{2}", DELIMITATOR, SPOT_COLOUR_VISIBLE_CODE, source.Visible ? TRUE : FALSE);
                b.AppendFormat("{0}{1}{2:0.0}", DELIMITATOR, SPOT_COLOUR_CYAN_CODE, source.Cyan);
                b.AppendFormat("{0}{1}{2:0.0}", DELIMITATOR, SPOT_COLOUR_MAGENTA_CODE, source.Magenta);
                b.AppendFormat("{0}{1}{2:0.0}", DELIMITATOR, SPOT_COLOUR_YELLOW_CODE, source.Yellow);
                b.AppendFormat("{0}{1}{2:0.0}", DELIMITATOR, SPOT_COLOUR_BLACK_CODE, source.Black);
                b.AppendFormat("{0}{1}{2:0.0}", DELIMITATOR, SPOT_COLOUR_FREQUENCY_CODE, source.FrequencyLpi * 10);
                b.AppendFormat("{0}{1}{2:0.0}", DELIMITATOR, SPOT_COLOUR_HALFTONE_ANGLE_CODE, source.HalftoneAngle);
                setting.ConcatenatedValues = b.ToString();
            }
        }
    }
}
