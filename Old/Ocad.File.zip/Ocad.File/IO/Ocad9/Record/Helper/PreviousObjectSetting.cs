﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;

namespace Ocad.IO.Ocad9.Record.Helper
{
    internal partial class Setting
    {
        private const String PREVIOUS_OBJECT_DESCRIPTION = "d";
        private const String PREVIOUS_OBJECT_START_POINT_OF_LINE = "f";
        private const String PREVIOUS_OBJECT_END_POINT_OF_LINE = "t";

        private void CopyToModelPreviousObject(Model.Header header)
        {
            Model.PreviousObject setting = new Model.PreviousObject();
            header.PreviousObjects.Add(setting);

            setting.CourseName = this.mainValue;

            int i = 0;
            while (i <= this.codeValue.GetUpperBound(0))
            {
                string code = this.codeValue[i, 0];
                switch (code)
                {
                    case PREVIOUS_OBJECT_DESCRIPTION:
                        setting.Description = this.codeValue[i, 1];
                        break;
                    case PREVIOUS_OBJECT_START_POINT_OF_LINE:
                        setting.StartPointOfLine = this.codeValue[i, 1];
                        break;
                    case PREVIOUS_OBJECT_END_POINT_OF_LINE:
                        setting.EndPointOfLine = this.codeValue[i, 1];
                        break;
                }
                i++;
            }
        }

        private static void CopyFromModelPreviousObjects(Model.Header header, List<Setting> settings)
        {
            foreach (Model.PreviousObject source in header.PreviousObjects)
            {
                Setting setting = new Setting();
                setting.SettingType = Type.SettingType.PreviousObject;
                settings.Add(setting);

                StringBuilder b = new StringBuilder(source.CourseName);
                b.AppendFormat("{0}{1}{2}", DELIMITATOR, PREVIOUS_OBJECT_DESCRIPTION, source.Description);
                b.AppendFormat("{0}{1}{2}", DELIMITATOR, PREVIOUS_OBJECT_START_POINT_OF_LINE, source.StartPointOfLine);
                b.AppendFormat("{0}{1}{2}", DELIMITATOR, PREVIOUS_OBJECT_END_POINT_OF_LINE, source.EndPointOfLine);

                setting.ConcatenatedValues = b.ToString();
            }
        }
    }
}
