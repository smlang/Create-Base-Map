﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;

namespace Ocad.IO.Ocad9.Record.Helper
{
    internal partial class Setting
    {
        internal const Char DELIMITATOR = '\t';
        internal const String TRUE = "1";
        internal const String FALSE = "0";

        internal Type.SettingType SettingType { get; set; }
        internal Int32 Index { get; set; }
        internal String ConcatenatedValues { get; set; }

        private String mainValue;
        private String[,] codeValue;

        internal void CopyToModel(Reader reader)
        {
            String[] parts = ConcatenatedValues.Split(Setting.DELIMITATOR);

            mainValue = parts[0];
            codeValue = new String[parts.Length - 1, 2];
            for (Int32 i = 1; i < parts.Length; i++)
            {
                codeValue[i - 1, 0] = parts[i][0].ToString();
                codeValue[i - 1, 1] = parts[i].Substring(1);
            }

            switch (SettingType)
            {
                //case Type.SettingType.CourseSettingObject:
                //    break;
                //case Type.SettingType.Course:
                //    break;
                //case Type.SettingType.CourseSettingClass:
                //    break;
                case Type.SettingType.DataSet:
                    CopyToModelDataSet(reader.ModelHeader);
                    break;
                case Type.SettingType.DatabaseObject:
                    CopyToModelDatabaseObject(reader.ModelHeader);
                    break;
                case Type.SettingType.OimFile:
                    CopyToModelOimFile(reader.ModelHeader);
                    break;
                case Type.SettingType.PreviousObject:
                    CopyToModelPreviousObject(reader.ModelHeader);
                    break;
                case Type.SettingType.Template:
                    CopyToModelTemplate(reader.ModelHeader);
                    break;
                case Type.SettingType.Colour:
                    CopyToModelColour(reader.ModelHeader);
                    break;
                case Type.SettingType.SpotColour:
                    CopyToModelSpotColour(reader.ModelHeader);
                    break;
                case Type.SettingType.FileInfo:
                    CopyToModelFileInfo(reader.ModelHeader);
                    break;
                case Type.SettingType.Zoom:
                    CopyToModelZoom(reader.ModelHeader);
                    break;
                case Type.SettingType.ImportLayer:
                    CopyToModelImportLayer(reader.ModelHeader);
                    break;
                case Type.SettingType.OimFind:
                    CopyToModelOimFind(reader.ModelHeader);
                    break;
                case Type.SettingType.SymbolTree:
                    CopyToModelSymbolTree(reader.ModelHeader);
                    break;
                case Type.SettingType.DisplayParameter:
                    CopyToModelDisplayParameter(reader.ModelHeader);
                    break;
                case Type.SettingType.OimParameter:
                    CopyToModelOimParameter(reader.ModelHeader);
                    break;
                case Type.SettingType.PrintParameter:
                    CopyToModelPrintParameter(reader.ModelHeader);
                    break;
                //case Type.SettingType.ControlDescriptionPrintParameter:
                //    break;
                case Type.SettingType.TemplateParameter:
                    CopyToModelTemplateParameter(reader.ModelHeader);
                    break;
                case Type.SettingType.EpsParameter:
                    CopyToModelEpsParameter(reader.ModelHeader);
                    break;
                case Type.SettingType.ViewParameter:
                    CopyToModelViewParameter(reader.ModelHeader);
                    break;
                //case Type.SettingType.CourseParameter:
                //    break;
                case Type.SettingType.TiffParameter:
                    CopyToModelTiffParameter(reader.ModelHeader);
                    break;
                case Type.SettingType.TilesParameter:
                    CopyToModelTilesParameter(reader.ModelHeader);
                    break;
                case Type.SettingType.DatabaseParameter:
                    CopyToModelDatabaseParameter(reader.ModelHeader);
                    break;
                case Type.SettingType.ExportParameter:
                    CopyToModelExportParameter(reader.ModelHeader);
                    break;
                //case Type.SettingType.ExportCourseSettingTextParameter:
                //    break;
                //case Type.SettingType.ExportCourseSettingStatParameter:
                //    break;
                case Type.SettingType.ScaleParameter:
                    CopyToModelScaleParameter(reader.ModelHeader);
                    break;
                case Type.SettingType.DatabaseCreateObjectParameter:
                    CopyToModelDatabaseCreateObjectParameter(reader.ModelHeader);
                    break;
                case Type.SettingType.XmlScriptParameter:
                    CopyToModelXmlScriptParameter(reader.ModelHeader);
                    break;
                default:
                    CopyToModelMiscellaneous(reader.ModelHeader);
                    break;
            }
        }

        internal static List<Setting> CopyFromModel(Model.Header header)
        {
            List<Setting> settings = new List<Setting>();

            //CopyFromModelCourseSettingObjects(header, settings);
            //CopyFromModelCourses(header, settings);
            //CopyFromModelCourseSettingClasses(header, settings);
            CopyFromModelDataSets(header, settings);
            CopyFromModelDatabaseObjects(header, settings);
            CopyFromModelOimFiles(header, settings);
            CopyFromModelPreviousObjects(header, settings);
            CopyFromModelTemplates(header, settings);
            CopyFromModelColours(header, settings);
            CopyFromModelSpotColours(header, settings);
            CopyFromModelFileInfos(header, settings);
            CopyFromModelZooms(header, settings);
            CopyFromModelImportLayers(header, settings);
            CopyFromModelOimFinds(header, settings);
            CopyFromModelSymbolTrees(header, settings);

            CopyFromModelDisplayParameter(header, settings);
            CopyFromModelOimParameter(header, settings);
            CopyFromModelPrintParameter(header, settings);
            //CopyFromModelControlDescriptionPrintParameter(header, settings);
            CopyFromModelTemplateParameter(header, settings);
            CopyFromModelEpsParameter(header, settings);
            CopyFromModelViewParameter(header, settings);
            //CopyFromModelCourseParameter(header, settings);
            CopyFromModelTiffParameter(header, settings);
            CopyFromModelTilesParameter(header, settings);
            CopyFromModelDatabaseParameter(header, settings);
            CopyFromModelExportParameter(header, settings);
            //CopyFromModelExportCourseSettingTextParameter(header, settings);
            //CopyFromModelExportCourseSettingStatParameter(header, settings);
            CopyFromModelScaleParameter(header, settings);
            CopyFromModelDatabaseCreateObjectParameter(header, settings);
            CopyFromModelXmlScriptParameter(header, settings);
            CopyFromModelMiscellaneousSettings(header, settings);

            return settings;
        }
    }
}
