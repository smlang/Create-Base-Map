﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;

namespace Ocad.IO.Ocad9.Record.Helper
{
    internal partial class Setting
    {
        private void CopyToModelOimFile(Model.Header header)
        {
            Model.OimFile setting = new Model.OimFile();
            header.OimFiles.Add(setting);

            setting.FileName = this.mainValue;
        }

        private static void CopyFromModelOimFiles(Model.Header header, List<Setting> settings)
        {
            foreach (Model.OimFile source in header.OimFiles)
            {
                Setting setting = new Setting();
                setting.SettingType = Type.SettingType.OimFile;
                settings.Add(setting);

                setting.ConcatenatedValues = source.FileName;
            }
        }
    }
}
