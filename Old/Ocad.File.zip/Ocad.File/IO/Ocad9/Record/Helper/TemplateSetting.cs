﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;

namespace Ocad.IO.Ocad9.Record.Helper
{
    internal partial class Setting
    {
        private const String TEMPLATE_OMEGA_ANGLE = "a";
        private const String TEMPLATE_PHI_ANGLE = "b";
        private const String TEMPLATE_DIM = "d";
        private const String TEMPLATE_RENDER_WITH_SPOT_COLOUR = "o";
        private const String TEMPLATE_ASSIGNED_TO_SPOT_COLOUR = "p";
        private const String TEMPLATE_SUBTRACT_FROM_SPOT_COLOUR = "q";
        private const String TEMPLATE_VISIBLE_IN_DRAFT_MODE = "r";
        private const String TEMPLATE_VISIBLE_IN_NORMAL_MODE = "s";
        private const String TEMPLATE_TRANSPARENT = "t";
        private const String TEMPLATE_OFFSET_CENTRE_X_MM = "x";
        private const String TEMPLATE_OFFSET_CENTRE_Y_MM = "y";
        private const String TEMPLATE_PIXEL_SIZE_X_MM = "u";
        private const String TEMPLATE_PIXEL_SIZE_Y_MM = "v";

        private void CopyToModelTemplate(Model.Header header)
        {
            Model.Template setting = new Model.Template();
            header.Templates.Add(setting);

            setting.FileName = this.mainValue;

            int i = 0;
            while (i <= this.codeValue.GetUpperBound(0))
            {
                string code = this.codeValue[i, 0];
                switch (code)
                {
                    case TEMPLATE_OMEGA_ANGLE:
                        setting.OmegaAngle = Double.Parse(this.codeValue[i, 1]);
                        break;
                    case TEMPLATE_PHI_ANGLE:
                        setting.PhiAngle = Double.Parse(this.codeValue[i, 1]);
                        break;
                    case TEMPLATE_DIM:
                        setting.Dim = Byte.Parse(this.codeValue[i, 1]);
                        break;
                    case TEMPLATE_RENDER_WITH_SPOT_COLOUR:
                        setting.RenderWithSpotColour = this.codeValue[i, 1];
                        break;
                    case TEMPLATE_ASSIGNED_TO_SPOT_COLOUR:
                        setting.AssignedToSpotColour = this.codeValue[i, 1];
                        break;
                    case TEMPLATE_SUBTRACT_FROM_SPOT_COLOUR:
                        setting.SubtractFromSpotColour = this.codeValue[i, 1];
                        break;
                    case TEMPLATE_VISIBLE_IN_DRAFT_MODE:
                        setting.VisibleInDraftMode = this.codeValue[i, 1].Equals(TRUE);
                        break;
                    case TEMPLATE_VISIBLE_IN_NORMAL_MODE:
                        setting.VisibleInNormalMode = this.codeValue[i, 1].Equals(TRUE);
                        break;
                    case TEMPLATE_TRANSPARENT:
                        setting.Transparent = this.codeValue[i, 1];
                        break;
                    case TEMPLATE_OFFSET_CENTRE_X_MM:
                        setting.OffsetCentreXMm = Double.Parse(this.codeValue[i, 1]);
                        break;
                    case TEMPLATE_OFFSET_CENTRE_Y_MM:
                        setting.OffsetCentreYMm = Double.Parse(this.codeValue[i, 1]);
                        break;
                    case TEMPLATE_PIXEL_SIZE_X_MM:
                        setting.PixelSizeXMm = Double.Parse(this.codeValue[i, 1]);
                        break;
                    case TEMPLATE_PIXEL_SIZE_Y_MM:
                        setting.PixelSizeYMm = Double.Parse(this.codeValue[i, 1]);
                        break;
                }
                i++;
            }
        }

        private static void CopyFromModelTemplates(Model.Header header, List<Setting> settings)
        {
            foreach (Model.Template source in header.Templates)
            {
                Setting setting = new Setting();
                setting.SettingType = Type.SettingType.Template;
                settings.Add(setting);

                StringBuilder b = new StringBuilder(source.FileName);
                b.AppendFormat("{0}{1}{2}", DELIMITATOR, TEMPLATE_VISIBLE_IN_NORMAL_MODE, source.VisibleInNormalMode ? TRUE : FALSE);
                b.AppendFormat("{0}{1}{2}", DELIMITATOR, TEMPLATE_VISIBLE_IN_DRAFT_MODE, source.VisibleInDraftMode ? TRUE : FALSE);
                b.AppendFormat("{0}{1}{2:0.0000000000}", DELIMITATOR, TEMPLATE_PIXEL_SIZE_X_MM, source.PixelSizeXMm);
                b.AppendFormat("{0}{1}{2:0.0000000000}", DELIMITATOR, TEMPLATE_PIXEL_SIZE_Y_MM, source.PixelSizeYMm);
                b.AppendFormat("{0}{1}{2:0.000000}", DELIMITATOR, TEMPLATE_OFFSET_CENTRE_X_MM, source.OffsetCentreXMm);
                b.AppendFormat("{0}{1}{2:0.000000}", DELIMITATOR, TEMPLATE_OFFSET_CENTRE_Y_MM, source.OffsetCentreYMm);
                b.AppendFormat("{0}{1}{2:0.00000000}", DELIMITATOR, TEMPLATE_OMEGA_ANGLE, source.OmegaAngle);
                b.AppendFormat("{0}{1}{2:0.00000000}", DELIMITATOR, TEMPLATE_PHI_ANGLE, source.PhiAngle);

                if (source.Dim.HasValue)
                {
                    b.AppendFormat("{0}{1}{2}", DELIMITATOR, TEMPLATE_DIM, source.Dim.Value);
                }
                if (source.RenderWithSpotColour != null)
                {
                    b.AppendFormat("{0}{1}{2}", DELIMITATOR, TEMPLATE_RENDER_WITH_SPOT_COLOUR, source.RenderWithSpotColour);
                }
                if (source.AssignedToSpotColour != null)
                {
                    b.AppendFormat("{0}{1}{2}", DELIMITATOR, TEMPLATE_ASSIGNED_TO_SPOT_COLOUR, source.AssignedToSpotColour);
                }
                if (source.SubtractFromSpotColour != null)
                {
                    b.AppendFormat("{0}{1}{2}", DELIMITATOR, TEMPLATE_SUBTRACT_FROM_SPOT_COLOUR, source.SubtractFromSpotColour);
                }
                if (source.Transparent != null)
                {
                    b.AppendFormat("{0}{1}{2}", DELIMITATOR, TEMPLATE_TRANSPARENT, source.Transparent);
                }
                setting.ConcatenatedValues = b.ToString();
            }
        }
    }
}
