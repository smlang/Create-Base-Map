﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;

namespace Ocad.IO.Ocad9.Record.Helper
{
    internal partial class Setting
    {
        private const String COLOUR_NUMBER_CODE = "n";
        private const String COLOUR_CYAN_CODE = "c";
        private const String COLOUR_MAGENTA_CODE = "m";
        private const String COLOUR_YELLOW_CODE = "y";
        private const String COLOUR_BLACK_CODE = "k";
        private const String COLOUR_OVERPRINT_CODE = "o";
        private const String COLOUR_TRANSPARENCY_CODE = "t";
        private const String COLOUR_SPOT_COLOUR_NAME_CODE = "s";
        private const String COLOUR_SPOT_COLOUR_PERCENTAGE = "p";

        private void CopyToModelColour(Model.Header header)
        {
            Int16 number = 0;
            int i = 0;
            int numberIndex = -1;
            while ((i <= this.codeValue.GetUpperBound(0)) && (numberIndex < 0))
            {
                string code = this.codeValue[i, 0];
                switch (code)
                {
                    case COLOUR_NUMBER_CODE:
                        number = Int16.Parse(this.codeValue[i, 1]);
                        numberIndex = i;
                        break;
                }
                i++;
            }

            Model.Colour setting = header.GetOrCreateColour(number, true);
            
            setting.Name = this.mainValue;
            while (i <= this.codeValue.GetUpperBound(0))
            {
                string code = this.codeValue[i, 0];
                switch (code)
                {
                    case COLOUR_CYAN_CODE:
                        setting.Cyan = Double.Parse(this.codeValue[i, 1]);
                        break;
                    case COLOUR_MAGENTA_CODE:
                        setting.Magenta = Double.Parse(this.codeValue[i, 1]);
                        break;
                    case COLOUR_YELLOW_CODE:
                        setting.Yellow = Double.Parse(this.codeValue[i, 1]);
                        break;
                    case COLOUR_BLACK_CODE:
                        setting.Black = Double.Parse(this.codeValue[i, 1]);
                        break;
                    case COLOUR_OVERPRINT_CODE:
                        setting.Overprint = this.codeValue[i, 1].Equals(TRUE);
                        break;
                    case COLOUR_TRANSPARENCY_CODE:
                        setting.Transparency = Double.Parse(this.codeValue[i, 1]);
                        break;
                    case COLOUR_SPOT_COLOUR_NAME_CODE:
                        String spotColourName = this.codeValue[i, 1];
                        Model.SpotColour spotColour = header.GetOrCreateSpotColour(spotColourName);
                        i++;
                        setting.SpotColours.Add(spotColour, Double.Parse(this.codeValue[i, 1]));
                        
                        break;
                }
                i++;
            }
        }

        private static void CopyFromModelColours(Model.Header header, List<Setting> settings)
        {
            foreach (Model.Colour source in header.Colours)
            {
                Setting setting = new Setting();
                setting.SettingType = Type.SettingType.Colour;
                settings.Add(setting);

                StringBuilder b = new StringBuilder(source.Name);
                b.AppendFormat("{0}{1}{2}", DELIMITATOR, COLOUR_NUMBER_CODE, source.Number);
                b.AppendFormat("{0}{1}{2:0.0}", DELIMITATOR, COLOUR_CYAN_CODE, source.Cyan);
                b.AppendFormat("{0}{1}{2:0.0}", DELIMITATOR, COLOUR_MAGENTA_CODE, source.Magenta);
                b.AppendFormat("{0}{1}{2:0.0}", DELIMITATOR, COLOUR_YELLOW_CODE, source.Yellow);
                b.AppendFormat("{0}{1}{2:0.0}", DELIMITATOR, COLOUR_BLACK_CODE, source.Black);
                b.AppendFormat("{0}{1}{2}", DELIMITATOR, COLOUR_OVERPRINT_CODE, source.Overprint ? TRUE : FALSE);
                if (source.Transparency.HasValue)
                {
                    b.AppendFormat("{0}{1}{2:0.0}", DELIMITATOR, COLOUR_TRANSPARENCY_CODE, source.Transparency.Value);
                }
                foreach (Model.SpotColour s in source.SpotColours.Keys)
                {
                    b.AppendFormat("{0}{1}{2}", DELIMITATOR, COLOUR_SPOT_COLOUR_NAME_CODE, s.Name);
                    b.AppendFormat("{0}{1}{2:0.0}", DELIMITATOR, COLOUR_SPOT_COLOUR_PERCENTAGE, source.SpotColours[s]);
                }
                setting.ConcatenatedValues = b.ToString();
            }
        }
    }
}
