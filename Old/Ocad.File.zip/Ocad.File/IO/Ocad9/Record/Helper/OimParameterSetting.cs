﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;

namespace Ocad.IO.Ocad9.Record.Helper
{
    internal partial class Setting
    {
        private const String OIM_PARAMETER_ANTI_ALIASING = "a";
        private const String OIM_PARAMETER_BORDER_WIDTH = "b";
        private const String OIM_PARAMETER_COMPRESSED_SVG = "c";
        private const String OIM_PARAMETER_EXTERNAL_SCRIPTING = "e";
        private const String OIM_PARAMETER_FIND_LABEL = "f";
        private const String OIM_PARAMETER_HEIGHT = "h";
        private const String OIM_PARAMETER_OVERVIEW_HEIGHT = "i";
        private const String OIM_PARAMETER_DO_NOT_CREATE_TILES = "m";
        private const String OIM_PARAMETER_ZOOM_RANGE = "r";
        private const String OIM_PARAMETER_SELECT_LABEL = "s";
        private const String OIM_PARAMETER_OVERVIEW_WIDTH = "v";
        private const String OIM_PARAMETER_WIDTH = "w";
        private const String OIM_PARAMETER_ZOOM_LEVELS = "z";
        private const String OIM_PARAMETER_FILL_COLOUR_RED = "R";
        private const String OIM_PARAMETER_FILL_COLOUR_GREEN = "G";
        private const String OIM_PARAMETER_FILL_COLOUR_BLUE = "B";
        private const String OIM_PARAMETER_OVERVIEW_MAP_NUMBER = "o";

        private void CopyToModelOimParameter(Model.Header header)
        {
            Model.OimParameter setting = new Model.OimParameter();
            header.OimParameter = setting;

            setting.FileName = this.mainValue;

            int i = 0;
            while (i <= this.codeValue.GetUpperBound(0))
            {
                string code = this.codeValue[i, 0];
                switch (code)
                {
                    case OIM_PARAMETER_ANTI_ALIASING:
                        setting.AntiAliasing = this.codeValue[i, 1].Equals(TRUE);
                        break;
                    case OIM_PARAMETER_BORDER_WIDTH:
                        setting.BorderWidth = Int32.Parse(this.codeValue[i, 1]);
                        break;
                    case OIM_PARAMETER_COMPRESSED_SVG:
                        setting.CompressedSvg = this.codeValue[i, 1].Equals(TRUE);
                        break;
                    case OIM_PARAMETER_EXTERNAL_SCRIPTING:
                        setting.ExternalScripting = this.codeValue[i, 1].Equals(TRUE);
                        break;
                    case OIM_PARAMETER_FIND_LABEL:
                        setting.FindLabel = this.codeValue[i, 1];
                        break;
                    case OIM_PARAMETER_HEIGHT:
                        setting.Height = Int32.Parse(this.codeValue[i, 1]);
                        break;
                    case OIM_PARAMETER_OVERVIEW_HEIGHT:
                        setting.OverviewHeight = Int32.Parse(this.codeValue[i, 1]);
                        break;
                    case OIM_PARAMETER_DO_NOT_CREATE_TILES:
                        setting.DoNotCreateFiles = this.codeValue[i, 1].Equals(TRUE);
                        break;
                    case OIM_PARAMETER_ZOOM_RANGE:
                        setting.ZoomRange = Double.Parse(this.codeValue[i, 1]);
                        break;
                    case OIM_PARAMETER_SELECT_LABEL:
                        setting.SelectLabel = this.codeValue[i, 1];
                        break;
                    case OIM_PARAMETER_OVERVIEW_WIDTH:
                        setting.OverviewWidth = Int32.Parse(this.codeValue[i, 1]);
                        break;
                    case OIM_PARAMETER_WIDTH:
                        setting.Width = Int32.Parse(this.codeValue[i, 1]);
                        break;
                    case OIM_PARAMETER_ZOOM_LEVELS:
                        setting.ZoomLevels = Byte.Parse(this.codeValue[i, 1]);
                        break;
                    case OIM_PARAMETER_FILL_COLOUR_RED:
                        setting.FillColourRed = Byte.Parse(this.codeValue[i, 1]);
                        break;
                    case OIM_PARAMETER_FILL_COLOUR_GREEN:
                        setting.FillColourGreen = Byte.Parse(this.codeValue[i, 1]);
                        break;
                    case OIM_PARAMETER_FILL_COLOUR_BLUE:
                        setting.FillColourBlue = Byte.Parse(this.codeValue[i, 1]);
                        break;
                    case OIM_PARAMETER_OVERVIEW_MAP_NUMBER:
                        setting.OverviewMapNumber = Byte.Parse(this.codeValue[i, 1]);
                        break;
                }
                i++;
            }
        }

        private static void CopyFromModelOimParameter(Model.Header header, List<Setting> settings)
        {
            Model.OimParameter source = header.OimParameter;
            if (source != null)
            {
                Setting setting = new Setting();
                setting.SettingType = Type.SettingType.OimParameter;
                settings.Add(setting);

                StringBuilder b = new StringBuilder(source.FileName);
                b.AppendFormat("{0}{1}{2:0.00}", DELIMITATOR, OIM_PARAMETER_ZOOM_RANGE, source.ZoomRange);
                b.AppendFormat("{0}{1}{2}", DELIMITATOR, OIM_PARAMETER_ZOOM_LEVELS, source.ZoomLevels);
                b.AppendFormat("{0}{1}{2}", DELIMITATOR, OIM_PARAMETER_DO_NOT_CREATE_TILES, source.DoNotCreateFiles ? TRUE : FALSE);
                b.AppendFormat("{0}{1}{2}", DELIMITATOR, OIM_PARAMETER_WIDTH, source.Width);
                b.AppendFormat("{0}{1}{2}", DELIMITATOR, OIM_PARAMETER_HEIGHT, source.Height);
                b.AppendFormat("{0}{1}{2}", DELIMITATOR, OIM_PARAMETER_OVERVIEW_WIDTH, source.OverviewWidth);
                b.AppendFormat("{0}{1}{2}", DELIMITATOR, OIM_PARAMETER_OVERVIEW_HEIGHT, source.OverviewHeight);
                b.AppendFormat("{0}{1}{2}", DELIMITATOR, OIM_PARAMETER_FILL_COLOUR_RED, source.FillColourRed);
                b.AppendFormat("{0}{1}{2}", DELIMITATOR, OIM_PARAMETER_FILL_COLOUR_GREEN, source.FillColourGreen);
                b.AppendFormat("{0}{1}{2}", DELIMITATOR, OIM_PARAMETER_FILL_COLOUR_BLUE, source.FillColourBlue);
                b.AppendFormat("{0}{1}{2}", DELIMITATOR, OIM_PARAMETER_EXTERNAL_SCRIPTING, source.ExternalScripting ? TRUE : FALSE);
                b.AppendFormat("{0}{1}{2}", DELIMITATOR, OIM_PARAMETER_SELECT_LABEL, source.SelectLabel);
                b.AppendFormat("{0}{1}{2}", DELIMITATOR, OIM_PARAMETER_FIND_LABEL, source.FindLabel);
                b.AppendFormat("{0}{1}{2}", DELIMITATOR, OIM_PARAMETER_BORDER_WIDTH, source.BorderWidth);
                b.AppendFormat("{0}{1}{2}", DELIMITATOR, OIM_PARAMETER_COMPRESSED_SVG, source.CompressedSvg ? TRUE : FALSE);
                b.AppendFormat("{0}{1}{2}", DELIMITATOR, OIM_PARAMETER_OVERVIEW_MAP_NUMBER, source.OverviewMapNumber);
                if (source.AntiAliasing.HasValue)
                {
                    b.AppendFormat("{0}{1}{2}", DELIMITATOR, OIM_PARAMETER_ANTI_ALIASING, source.AntiAliasing.Value ? TRUE : FALSE);
                }

                setting.ConcatenatedValues = b.ToString();
            }
        }
    }
}
